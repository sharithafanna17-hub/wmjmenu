#!/bin/bash
# 云端构建脚本：编译 dylib；若给了 ipa 链接，顺手打成可签名的 ipa
set -euo pipefail
IPA_URL="${1:-}"
cd "$(dirname "$0")"

echo "== 目录 =="; ls -la

echo "== 编译 dylib =="
SDK=$(xcrun --sdk iphoneos --show-sdk-path)
xcrun --sdk iphoneos clang++ -arch arm64 -dynamiclib -fobjc-arc -Ireimpl \
  -isysroot "$SDK" -miphoneos-version-min=15.0 \
  -framework UIKit -framework WebKit -framework Foundation \
  -o reimpl/libLCZMenu.dylib \
  reimpl/LCZMenuHost.mm reimpl/LCZHooks.mm reimpl/LCZIL2CPP.mm \
  -Wl,-install_name,@rpath/libLCZMenu.dylib -undefined dynamic_lookup
ls -lh reimpl/libLCZMenu.dylib
lipo -info reimpl/libLCZMenu.dylib || true

if [ -n "$IPA_URL" ]; then
  echo "== 下载 ipa =="
  curl -L --retry 3 --retry-delay 5 -o original.ipa "$IPA_URL"
  ls -lh original.ipa
  echo "== 打补丁 =="
  chmod +x dist/*.sh
  ./dist/build-ipa.sh --ipa original.ipa --dylib reimpl/libLCZMenu.dylib --out LCZMenu-patched.ipa
  ls -lh LCZMenu-patched.ipa
else
  echo "== 没给 ipa 链接，只出 dylib =="
fi
