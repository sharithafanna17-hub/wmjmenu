#!/usr/bin/env node
// 由 ipa/features.json + ipa/featuremap.json 生成复刻工程的配置与目标清单
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const feats = JSON.parse(fs.readFileSync(path.join(ROOT, 'ipa/features.json'), 'utf8'));
let fmap = [];
try { fmap = JSON.parse(fs.readFileSync(path.join(ROOT, 'ipa/featuremap.json'), 'utf8')); } catch (e) {}
const byKey = new Map(fmap.map(o => [o.key, o]));

// ---------- 分组 ----------
const RULES = [
  [/^esp_/, 'ESP / 透视'],
  [/^(god_mode|one_hit|damage_multiplier|never_miss|critical_hit|bullet_wall|attack_speed|freeze_enemies|hazard_immunity|skill_cooldown|combat_parameters|weapon_range|weapon_drone|rifle_nailgun|minigun_ready|nailgun_infinite_time|move_speed)/, '战斗'],
  [/^(camera_|player_fly|player_height|free_run|first_person|fog_distance|map_brightness|hide_roofs|role_view|drag_box_objects|ignore_floor|multiview)/i, '移动与相机'],
  [/^(inventory|item_|stack_limit|clear_inventory|clear_bodybags|send_inventory|send_full_weapon|quantity_editor|magic_split|infinite_items|quick_chest|quick_gather|loot_objects|resource_objects|location_objects|skins_temporary|split_equipment|pack_preserve|reclaim_furniture)/, '物品与库存'],
  [/^(build|unlimited_build|free_craft|fast_workbench|finalize_build|repair_infrastructure|grow_plants|gather)/, '建筑与制作'],
  [/(dog_|robodog_|pet)/, '宠物'],
  [/^(map_|minimap_|instant_travel|summon_|event_contract|season_furniture|settlement)/, '地图与传送'],
  [/^(mail|inbox|send_inbox|vip_unlock|survivor_premium|skip_craft_coin|remove_google_ads)/, '邮件 / 经济'],
  [/^(character_|unlock_all_skins|role_|summon_characters)/, '角色与皮肤'],
  [/^(show_fps|game_fps|hub_window|cat_window|esp_window|vehicle_window|mail_window|dog_window)/, '界面'],
  [/^(gunsmith_)/, '枪械工坊'],
  [/_(storage|inventory)$/, '容器'],
  [/^(lockpick_unrestricted|bunker_code|bypass_sync|needs_lock|not_ready|raider_tasks|task_manager|season_|hazard)/, '杂项 / 风险'],
];
function groupOf(key) {
  for (const [re, g] of RULES) if (re.test(key)) return g;
  return '其它';
}

// ---------- 从描述里提取疑似目标方法名（CamelCase） ----------
const KNOWN_TYPES = new Set(['Int32', 'Int64', 'Single', 'Double', 'Boolean', 'String', 'Vector2', 'Vector3']);
function methodsFromDesc(desc) {
  if (!desc) return [];
  const m = desc.match(/\b[A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+\b/g) || [];
  return [...new Set(m)].filter(x => !KNOWN_TYPES.has(x));
}

const out = [];
for (const f of feats) {
  const m = byKey.get(f.key) || {};
  const descMethods = methodsFromDesc(f.desc);
  const members = (m.members || []).filter(x => !KNOWN_TYPES.has(x) && x !== 'System');
  out.push({
    key: f.key,
    type: f.type,            // 1=bool 2=数值 3=其它(视为bool) 0=未知
    min: f.min, max: f.max, def: f.def,
    desc: f.desc || '',
    group: groupOf(f.key),
    target: {
      classes: m.classes || [],
      members: members.slice(0, 12),
      fromDesc: descMethods,
      fnRange: m.fn || null,
    },
  });
}
out.sort((a, b) => (a.group === b.group ? a.key.localeCompare(b.key) : a.group.localeCompare(b.group)));

// ---------- 1) web/features.js ----------
const js = '/* 自动生成：node gen.js —— 数据来自 libLCZMenuHost 的功能描述表 */\n' +
  'window.LCZ_FEATURES = ' + JSON.stringify(out, null, 1) + ';\n';
fs.writeFileSync(path.join(__dirname, 'web/features.js'), js);


// ---------- 1b) LCZHooks.generated.h ----------
let hdr = "// 自动生成，勿手改\ntypedef struct { const char *key; int type; double minv, maxv, defv; } LCZFeatureDef;\nstatic const LCZFeatureDef kLCZFeatures[] = {\n";
for (const o of out) {
  hdr += `  {"${o.key}", ${o.type === 2 ? 2 : 1}, ${o.type===2?(o.min??0):0}, ${o.type===2?(o.max??0):0}, ${o.def??0}},\n`;
}
hdr += "};\nstatic const int kLCZFeatureCount = " + out.length + ";\n";
fs.writeFileSync(path.join(__dirname, "LCZHooks.generated.h"), hdr);

// ---------- 2) TARGETS.md ----------
let md = '# 功能 → 目标 映射表（自动生成）\n\n';
md += '共 ' + out.length + ' 项。`classes` 来自 dylib 处理函数内引用的 `Assets.*` 类名；`members` 来自同函数内的方法/属性名；`desc` 里出现的方法名是作者注释里点名的目标。\n\n';
md += '| key | 类型 / 范围 | 目标类 | 目标方法（描述 + 成员） |\n|---|---|---|---|\n';
for (const o of out) {
  const rng = o.type === 2 ? `${o.min}~${o.max} (默认${o.def})` : 'bool';
  const cls = (o.target.classes[0] || '').replace('Assets.Core.', '') || '—';
  const meths = [...new Set([...o.target.fromDesc, ...o.target.members])].slice(0, 5).join(', ') || '—';
  md += `| \`${o.key}\` | ${rng} | ${o.type === 2 ? '' : ''}${cls} | ${meths} |\n`.replace(/\|\s*\|/g, '| — |');
}
fs.writeFileSync(path.join(ROOT, 'reimpl/TARGETS.md'), md);

// ---------- 3) 统计 ----------
const gstat = {};
for (const o of out) gstat[o.group] = (gstat[o.group] || 0) + 1;
console.log('features:', out.length);
console.log('groups:', JSON.stringify(gstat, null, 1));
console.log('with desc-methods:', out.filter(o => o.target.fromDesc.length).length);
console.log('with classes:', out.filter(o => o.target.classes.length).length);
