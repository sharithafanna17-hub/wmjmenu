# 功能 → 目标 映射表（自动生成）

共 121 项。`classes` 来自 dylib 处理函数内引用的 `Assets.*` 类名；`members` 来自同函数内的方法/属性名；`desc` 里出现的方法名是作者注释里点名的目标。

| key | 类型 / 范围 | 目标类 | 目标方法（描述 + 成员） |
|---|---|---|---|
| `esp_chests` | bool | Models.Characters.CharacterModel | LootObjects, DragBoxObjects, Height, LocationCamera, ContainsKey |
| `esp_lines` | bool | Game.Battle.Location.Generation.LocationTerrain.LocationController | LocationController, GetCorpses, BuilderController, GetBuildingController, Container |
| `esp_master` | bool | Models.Characters.CharacterModel | Height, LocationCamera, ContainsKey, CharacterContainer, MeshRenderer |
| `esp_names` | bool | — | — |
| `esp_resources` | bool | Models.Characters.CharacterModel | ResourceObjects, Height, LocationCamera, ContainsKey, CharacterContainer |
| `esp_settings` | bool | Game.Battle.Location.Generation.LocationTerrain.LocationController | IsElite, QuickRatingModel, LocationController, GetCorpses, BuilderController |
| `esp_window` | bool | Models.Characters.CharacterModel | UnityMain, SyncController, SyncUser, EnemyEntityModel, IsEliteField |
| `backpack_manager` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `clear_buildings` | bool | Models.Builder.Building.PlantFurnitureBuilding | GetResult, GetRecipeTime, MoveProgress, SetValue, GetValue |
| `clear_corpses` | bool | — | ClearDeadCharacters |
| `clear_inbox` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `clear_stones_grass` | bool | — | — |
| `drone_blueprints` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | BoolFlag, SetActive, Item2, Item1, GetAmount |
| `drone_dock_station` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `freeze_animals` | bool | Game.Battle.Location.Generation.LocationTerrain.LocationController | IsPlayerCreated, LocationController, GetCorpses, BuilderController, GetBuildingController |
| `furniture_bar` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `furniture_bookshelf` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `furniture_builder_chest` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `furniture_electric_parts_box` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `furniture_junk_box` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `gasoline_tank` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `gasoline_tank_t2` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `warehouse_manager` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `event_contract` | bool | Models.InventoryModels.InventoryStack.WeaponInventoryStack | ReputationModel, ContainsModule, HasDuplicatedModuleInSharedSlots, HasIncompatibleModuleInSharedSlots, LocationObjectModel |
| `instant_travel` | bool | Game.Battle | GlobalMapMovement, BattleController, CameraSystemController, SunLightSystem, LocationModel |
| `map_refresh` | bool | — | — |
| `map_teleport` | bool | — | PlayerChangeLocationReward, EnterLocation |
| `minimap_range` | 0~50 (默认1) | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `season_furniture` | bool | Models.Entity.IEntity | GameManager, CheckBuilderRequirement, StructureView, CheckUnlocked, GetActualCode |
| `settlement_temporary` | bool | Helpers | GetRoomInfo, SaveCurrentFile, SaveRootPath, Get, GetCurrentSave |
| `summon_boxes` | bool | — | CreateDragBox, RemoveItem |
| `summon_characters` | bool | — | AddAvatar |
| `dog_energy` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `dog_energy` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `dog_grow` | bool | Models.InventoryModels.InventoryStack | CheckGrown, CheckRemoveStack, Clear, GetCats, WeaponInventoryStack |
| `dog_window` | bool | — | — |
| `robodog_energy` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `robodog_energy` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `robodog_reset` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `furniture_decor_storage` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `furniture_ore_storage` | bool | Game.Battle.CameraSystem | CameraSystemController, LocationCamera, CameraTransform, BattleController, CharacterController |
| `fast_workbench` | bool | — | GetRecipeTime |
| `finalize_build` | bool | Models.Entity.IEntity | IsBuilt, OnFinalizeClick, IsCompleted, CheckUnlocked, GetActualCode |
| `free_craft` | bool | Models.Entity.IEntity | InventoryStacksPrice, Deactivate, GetAmount, SetAmount, Remove |
| `gather_enemies` | bool | — | — |
| `grow_plants` | bool | Models.Builder.Building.PlantFurnitureBuilding | DoublePrivate, SetValue, MoveProgress, GetResult, GetRecipeTime |
| `repair_infrastructure` | bool | — | CheckToComplete, StartComplete |
| `unlimited_build` | bool | Models.Builder.Building.PlantFurnitureBuilding | GetResult, GetRecipeTime, MoveProgress, SetValue, GetValue |
| `attack_speed` | 1~10 (默认0.25) | Models.DomainSpecificLanguage.Amount.IAmount | GetAttackSpeedModifier, CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed |
| `bullet_wall` | bool | Sync.Controllers.Battle.Entities | CheckWalls, UnityEngine, WorldToScreenPoint, RenderSettings, SyncCharacterController |
| `combat_parameters` | bool | Models.DomainSpecificLanguage.LocationActions.Descriptions.AoeOverheatWeaponAttackLocationActionDescription | GetWeaponDescription, SetAmount, GetAmount, CharacterContainer, Transfrom |
| `critical_hit` | bool | Game.Battle | WeaponAttackLocationAction, HasCritical, BattleController, CameraSystemController, SunLightSystem |
| `damage_multiplier` | 1~999 (默认0.5) | — | CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed, Hit |
| `freeze_enemies` | bool | Game.Battle.Location.Generation.LocationTerrain.LocationController | HaveTarget, IsPlayerCreated, ClearTarget, LocationController, GetCorpses |
| `god_mode` | bool | — | ProcessHealthAmount, CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed |
| `hazard_immunity` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `minigun_ready` | bool | Game.Battle | AddHeat, AddRotation, BattleController, CameraSystemController, SunLightSystem |
| `move_speed` | 1~10 (默认0.25) | — | GetSpeed, CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed |
| `nailgun_infinite_time` | bool | — | — |
| `never_miss` | bool | Game.Battle | ProcessHit, BattleController, CameraSystemController, SunLightSystem, LocationModel |
| `one_hit` | bool | Models.Characters | Attitude, Aggressive |
| `skill_cooldown` | bool | Game.Battle | CooldownTs, BattleController, CameraSystemController, SunLightSystem, LocationModel |
| `weapon_range` | 0~100 (默认1) | Game.Battle | WeaponView, BattleController, CameraSystemController, SunLightSystem, LocationModel |
| `bunker_code` | bool | Models.Entity.IEntity | CodeLocationsCollection, CheckUnlocked, GetActualCode, Enter, GetMaximumDurability |
| `bypass_sync` | bool | Models.Entity.IEntity | BuildingCollection, CheckToComplete, StartComplete, REPAIR_SELECTED_INFRASTRUCTURE, Height |
| `lockpick_unrestricted` | bool | Models.Entity.IEntity | NotifyRandomPerkGradeChecker, Deactivate, GetAmount, SetAmount, Remove |
| `needs_lock` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `not_ready` | bool | — | — |
| `raider_tasks` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `season_access` | bool | Models.InventoryModels.InventoryStack.WeaponInventoryStack | ResourceRequirement, OnCheck, RewardsBattlePassModel, BattlePassModel, ContainsModule |
| `season_max_level` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `task_manager` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | QuestModel, Item2, Item1, GetAmount, GetMaximumDurability |
| `gunsmith_blueprints` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | BoolFlag, SetActive, Item2, Item1, GetAmount |
| `gunsmith_free` | bool | — | — |
| `gunsmith_modules` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | PlayerCollectionModels, StartComplete, IsCompleted, Item2, Item1 |
| `gunsmith_temporary` | bool | Models.Entity.IEntity | CheckSetModule, ModCollectionController, CheckAvailable, WeaponTableModsController, GetAvailableStatus |
| `clear_bodybags` | bool | — | — |
| `clear_inventory` | bool | — | CheckRemoveStack |
| `infinite_items` | bool | Models.Entity.IEntity | ConsumeInventoryItemBehaviour, Deactivate, GetAmount, SetAmount, Remove |
| `item_catalog` | bool | — | — |
| `magic_split` | 1~999999 (默认1) | Models.Entity.IEntity | LimitedInventoryStack, ChangeAmount, Deactivate, GetAmount, SetAmount |
| `pack_preserve` | bool | Models.InventoryModels.InventoryStack | ShopInboxGachaItem, CheckRemoveStack, Clear, GetCats, WeaponInventoryStack |
| `quantity_editor` | bool | Models.DomainSpecificLanguage.Amount.IAmount | SingleAmount, GetAmount, SetAmount |
| `quick_chest` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `quick_gather` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `reclaim_furniture` | bool | Models.Builder.Building.PlantFurnitureBuilding | GetResult, GetRecipeTime, MoveProgress, SetValue, GetValue |
| `send_full_weapon` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `send_inventory` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `skins_temporary` | bool | Models.Entity.IEntity | CharacterSkin, PaintIsLocked, Deactivate, GetAmount, SetAmount |
| `split_equipment` | bool | Models.Entity.IEntity | CheckSplit, Deactivate, GetAmount, SetAmount, Remove |
| `stack_limit` | 0~100000000 (默认1) | Models.Entity.IEntity | Deactivate, GetAmount, SetAmount, Remove, GetValue |
| `cat_window` | bool | — | — |
| `game_fps` | bool | — | CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed, Hit |
| `hub_window` | bool | Models.DomainSpecificLanguage.Reward.IReward | Height, DialogsManager, DialogsController, GetAmount, ContainsKey |
| `show_fps` | bool | Manager | GameManager, Instance, BattleController, CameraSystemController, CameraHeight |
| `vehicle_window` | bool | Models.Resources.ExperienceResource | GetAmount, SetAmount, GetAllTransport, MAX_CURRENT_VEHICLE_LEVEL, GetCurrentMaxExperienceAmount |
| `camera_distance` | 1~80 (默认1) | — | GetCameraDistance, CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed |
| `camera_height` | 1~30 (默认1) | — | CameraHeight, CameraReset |
| `camera_sync` | bool | — | CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed, Hit |
| `camera_x` | 0~360 (默认1) | — | CameraReset |
| `camera_y` | 0~90 (默认1) | — | CameraReset |
| `fog_distance` | -21~30 (默认1) | — | — |
| `free_run` | bool | Game.Battle | BattleController, CameraSystemController, SunLightSystem, LocationModel, LocationViewDescription |
| `hide_roofs` | bool | Sync.Controllers.Battle.Entities | BuilderController, ShowRoof, UnityEngine, WorldToScreenPoint, RenderSettings |
| `ignore_floor` | bool | Models.Builder.Building.PlantFurnitureBuilding | GetResult, GetRecipeTime, MoveProgress, SetValue, GetValue |
| `map_brightness` | 1~5 (默认0.25) | — | — |
| `player_fly` | bool | Game.Battle.Location.Generation.LocationTerrain.LocationController | LocationController, GetCorpses, BuilderController, GetBuildingController, Container |
| `player_height` | 0~40 (默认0.5) | Game.Battle.Location.Generation.LocationTerrain.LocationController | CollisionFlags, LocationController, GetCorpses, BuilderController, GetBuildingController |
| `role_view` | bool | — | CameraDispose, CameraUpdate, MoveSpeed, AttackSpeed, Hit |
| `character_appearance` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `character_max_level` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `character_skins` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `unlock_all_skins` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `inbox_infinite` | 0~100000 (默认1) | Models.InventoryModels.InventoryStack | CheckRemoveStack, Clear, GetCats, WeaponInventoryStack, WeaponTimeInventoryStack |
| `mail_window` | bool | — | — |
| `mailbox_manager` | bool | Models.InventoryModels.InventoryStack.KittenInventoryStack | Item2, Item1, GetAmount, GetMaximumDurability, Dispose |
| `remove_google_ads` | bool | Models.InventoryModels.InventoryStack.WeaponInventoryStack | AdsManager, ShowRealAd, CompletedAwaiter, ShowAd, ResolveWatchedAds |
| `send_inbox` | bool | — | — |
| `skip_craft_coin` | bool | — | SkipPriceAmount, GetSkipPriceAmount |
| `survivor_premium` | bool | Models.Entity.IEntity | EntityContext, CheckUnlocked, GetActualCode, Enter, GetMaximumDurability |
| `vip_unlock` | bool | Models.Entity.IEntity | CheckUnlocked, GetActualCode, Enter, GetMaximumDurability, GetValue |
