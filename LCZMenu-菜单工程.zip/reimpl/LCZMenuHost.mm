// LCZMenuHost.mm —— 菜单宿主（WKWebView + 自定义 scheme + JS 桥 + 键盘免疫）
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <objc/runtime.h>
#import "LCZIL2CPP.h"

@class LCZMenuHost;

// 容器本身不吃触摸，只有它的子视图（悬浮球/菜单页）才命中 —— 否则整个屏幕都会挡住游戏
@interface LCZPassthroughView : UIView @end
@implementation LCZPassthroughView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    return (v == self) ? nil : v;
}
@end

// 由 LCZHooks.mm 提供（自动生成）
extern void LCZDispatchJSCommand(NSString *action, NSString *key, id value);
extern NSDictionary *LCZBuildInitialState(void);

#pragma mark - scheme handler

@interface LCZSchemeHandler : NSObject <WKURLSchemeHandler>
@property (nonatomic, strong) NSURL *webRoot;
@end

@implementation LCZSchemeHandler
- (void)webView:(WKWebView *)webView startURLSchemeTask:(id<WKURLSchemeTask>)task {
    NSURL *url = task.request.URL;
    NSString *path = url.path.length ? url.path : @"/index.html";
    if ([path isEqualToString:@"/"]) path = @"/index.html";
    NSString *file = [self.webRoot.path stringByAppendingString:path];
    NSData *data = [NSData dataWithContentsOfFile:file];
    if (!data) {
        [task didFailWithError:[NSError errorWithDomain:@"lcz-menu" code:404 userInfo:
            @{NSLocalizedDescriptionKey: [NSString stringWithFormat:@"not found: %@", path]}]];
        return;
    }
    NSString *mime = @"application/octet-stream";
    if ([path hasSuffix:@".html"]) mime = @"text/html; charset=utf-8";
    else if ([path hasSuffix:@".js"]) mime = @"application/javascript; charset=utf-8";
    else if ([path hasSuffix:@".css"]) mime = @"text/css; charset=utf-8";
    else if ([path hasSuffix:@".png"]) mime = @"image/png";
    else if ([path hasSuffix:@".json"]) mime = @"application/json";
    NSHTTPURLResponse *resp = [[NSHTTPURLResponse alloc] initWithURL:url statusCode:200
        HTTPVersion:@"HTTP/1.1" headerFields:@{@"Content-Type": mime, @"Access-Control-Allow-Origin": @"*"}];
    [task didReceiveResponse:resp];
    [task didReceiveData:data];
    [task didFinish];
}
- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id<WKURLSchemeTask>)task {}
@end

#pragma mark - menu host

@interface LCZMenuHost : NSObject <WKScriptMessageHandler>
@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) UIButton *fab;
@property (nonatomic, assign) BOOL open;
+ (instancetype)shared;
- (void)install;
- (void)toggle;
@end

@implementation LCZMenuHost

+ (instancetype)shared {
    static LCZMenuHost *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [LCZMenuHost new]; });
    return s;
}

- (UIWindow *)keyWindow {
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.isKeyWindow) return w;
    }
    return UIApplication.sharedApplication.windows.firstObject;
}

- (void)install {
    // ---- 窗口：固定为屏幕尺寸，绝不跟随键盘 ----
    UIWindow *w = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    w.windowLevel = UIWindowLevelAlert + 1;
    w.backgroundColor = UIColor.clearColor;
    w.autoresizingMask = UIViewAutoresizingNone;
    UIViewController *vc = [UIViewController new];
    vc.view = [[LCZPassthroughView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    vc.view.backgroundColor = UIColor.clearColor;
    vc.view.autoresizingMask = UIViewAutoresizingNone;
    w.rootViewController = vc;
    self.window = w;

    // ---- WebView ----
    WKWebViewConfiguration *cfg = [WKWebViewConfiguration new];
    cfg.websiteDataStore = [WKWebsiteDataStore nonPersistentDataStore];
    cfg.allowsInlineMediaPlayback = YES;
    cfg.suppressesIncrementalRendering = NO;
    LCZSchemeHandler *handler = [LCZSchemeHandler new];
    // 注入式安装：资源放在 /Library/Application Support/LCZMenu/web
    // 打包进 app 时：app 包内 LCZMenu.bundle
    NSArray *cands = @[
        @"/Library/Application Support/LCZMenu/web",
        [[NSBundle mainBundle].bundlePath stringByAppendingPathComponent:@"LCZMenu.bundle/web"],
        [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"LCZMenu/web"],
    ];
    for (NSString *p in cands) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:[p stringByAppendingPathComponent:@"index.html"]]) {
            handler.webRoot = [NSURL fileURLWithPath:p];
            break;
        }
    }
    if (!handler.webRoot) NSLog(@"[LCZ] 找不到 LCZMenu/web/index.html");
    [cfg setURLSchemeHandler:handler forURLScheme:@"lcz-menu"];
    [cfg.userContentController addScriptMessageHandler:self name:@"lcz"];

    // 防止 iOS 自动放大：viewport 锁死 + 输入框 16px + 禁止双击/pinch 缩放
    NSString *lockdown = @
      "var m=document.querySelector('meta[name=viewport]');"
      "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"
      "m.content='width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,viewport-fit=cover';"
      "document.addEventListener('gesturestart',function(e){e.preventDefault();},false);"
      "document.addEventListener('dblclick',function(e){e.preventDefault();},false);";
    WKUserScript *us = [[WKUserScript alloc] initWithSource:lockdown
        injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:YES];
    [cfg.userContentController addUserScript:us];

    WKWebView *web = [[WKWebView alloc] initWithFrame:w.bounds configuration:cfg];
    web.backgroundColor = UIColor.clearColor;
    web.opaque = NO;
    web.autoresizingMask = UIViewAutoresizingNone;
    // ★ 键盘导致"分辨率被顶大/飞出屏幕"的四条根因，逐条掐死：
    web.scrollView.scrollEnabled = NO;                                  // 1. 不许滚动
    web.scrollView.bounces = NO;
    web.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever; // 2. 不按 safeArea/键盘改 inset
    web.scrollView.automaticallyAdjustsScrollIndicatorInsets = NO;
    web.scrollView.minimumZoomScale = 1.0;                              // 3. 禁止 pinch 放大（zoomScale 变了就是"被顶大"）
    web.scrollView.maximumZoomScale = 1.0;
    web.scrollView.pinchGestureRecognizer.enabled = NO;
    web.scrollView.delaysContentTouches = NO;
    if (@available(iOS 16.0, *)) web.scrollView.allowsKeyboardScrolling = NO;
    self.webView = web;
    [vc.view addSubview:web];

    // ---- 悬浮球 ----
    CGFloat s = 52;
    UIButton *fab = [UIButton buttonWithType:UIButtonTypeCustom];
    fab.frame = CGRectMake(w.bounds.size.width - s - 16, 96, s, s);
    fab.layer.cornerRadius = s / 2;
    fab.backgroundColor = [UIColor colorWithWhite:0.1 alpha:0.82];
    fab.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.18].CGColor;
    fab.layer.borderWidth = 1;
    [fab setTitle:@"LCZ" forState:UIControlStateNormal];
    [fab setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    fab.titleLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightBold];
    [fab addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
    [fab addGestureRecognizer:pan];
    self.fab = fab;
    [vc.view addSubview:fab];

    web.hidden = YES;
    w.hidden = NO;   // 只显示，不 makeKey：key window 必须留给游戏

    NSURL *url = [NSURL URLWithString:@"lcz-menu://local/index.html"];
    [web loadRequest:[NSURLRequest requestWithURL:url]];

    // ---- 键盘免疫通知：出现/消失都强制回写几何 ----
    NSArray *names = @[UIKeyboardWillShowNotification, UIKeyboardWillHideNotification,
                       UIKeyboardDidShowNotification, UIKeyboardDidHideNotification];
    for (NSString *n in names) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onKeyboard:)
                                                     name:n object:nil];
    }
}

- (void)onKeyboard:(NSNotification *)note {
    // 不跟随键盘做任何布局；只把被系统/WebKit 改动过的几何还原回去
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *root = self.window.rootViewController.view;
        [UIView performWithoutAnimation:^{
            self.window.frame = UIScreen.mainScreen.bounds;
            self.window.transform = CGAffineTransformIdentity;
            root.frame = self.window.bounds;
            root.transform = CGAffineTransformIdentity;
            if (self.open) {
                self.webView.frame = root.bounds;
                self.webView.transform = CGAffineTransformIdentity;
                UIScrollView *sv = self.webView.scrollView;
                sv.contentInset = UIEdgeInsetsZero;
                sv.scrollIndicatorInsets = UIEdgeInsetsZero;
                if (sv.zoomScale != 1.0) [sv setZoomScale:1.0 animated:NO];
                sv.contentOffset = CGPointZero;
            }
        }];
        // 告诉页面：键盘事件请自行忽略，保持设计尺寸
        [self.webView evaluateJavaScript:@"window.LCZ&&LCZ.onNativeGeometryLocked&&LCZ.onNativeGeometryLocked()"
                       completionHandler:nil];
    });
}

- (void)onPan:(UIPanGestureRecognizer *)g {
    CGPoint t = [g translationInView:self.window];
    CGPoint c = CGPointMake(self.fab.center.x + t.x, self.fab.center.y + t.y);
    CGFloat s = self.fab.bounds.size.width;
    c.x = MAX(s / 2 + 4, MIN(self.window.bounds.size.width - s / 2 - 4, c.x));
    c.y = MAX(s / 2 + 4, MIN(self.window.bounds.size.height - s / 2 - 4, c.y));
    self.fab.center = c;
    [g setTranslation:CGPointZero inView:self.window];
}

- (void)toggle {
    self.open = !self.open;
    self.webView.hidden = !self.open;
    if (self.open) {
        self.webView.frame = self.window.rootViewController.view.bounds;
        [self.webView evaluateJavaScript:@"window.LCZ&&LCZ.open()" completionHandler:nil];
    }
}

#pragma mark - JS 桥

- (void)userContentController:(WKUserContentController *)ucc didReceiveScriptMessage:(WKScriptMessage *)message {
    if (![message.name isEqualToString:@"lcz"]) return;
    id body = message.body;
    if (![body isKindOfClass:NSDictionary.class]) return;
    NSString *action = body[@"action"];   // "set" / "reset" / "state" / "close"
    NSString *key    = body[@"key"];
    id value         = body[@"value"];
    if ([action isEqualToString:@"close"]) { [self toggle]; return; }
    if ([action isEqualToString:@"state"]) {
        NSDictionary *st = LCZBuildInitialState();
        NSString *json = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:st options:0 error:nil]
                                              encoding:NSUTF8StringEncoding];
        NSString *js = [NSString stringWithFormat:@"window.LCZ&&LCZ.state(%@)", json];
        [self.webView evaluateJavaScript:js completionHandler:nil];
        return;
    }
    // 交给 hook 层执行（内部按 key 查表，未知 key 忽略）
    LCZDispatchJSCommand(action, key, value);
}

@end

#pragma mark - 启动

__attribute__((constructor)) static void LCZMenuBootstrap(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!LCZIl2cppInit()) NSLog(@"[LCZ] il2cpp 未就绪，菜单仍会显示，但功能不可用");
        [[LCZMenuHost shared] install];
    });
}
