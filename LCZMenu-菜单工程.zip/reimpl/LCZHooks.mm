// LCZHooks.mm —— 功能执行层（表驱动 + il2cpp hook）
//
// 设计：网页只发 { action: "set"|"reset", key, value }，这里按 key 分发到具体实现。
// 每个功能 = 一个"应用函数"：收到值就改运行时状态（hook 后的全局量 / 字段 / 方法指针）。
// 好处：菜单 UI 与游戏版本完全解耦，加功能只加一个 case。
#import "LCZIL2CPP.h"
#import "LCZHooks.generated.h"
#import <unistd.h>

static NSMutableDictionary<NSString *, NSNumber *> *gOn;     // key -> @(bool)
static NSMutableDictionary<NSString *, NSNumber *> *gVal;    // key -> @(double)
static NSString *const kPrefsKey = @"lcz.menu.prefs.v2";

#pragma mark - 状态

static void LCZLoadPrefs(void) {
    if (gOn) return;
    gOn = [NSMutableDictionary new];
    gVal = [NSMutableDictionary new];
    NSDictionary *saved = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kPrefsKey] ?: @{};
    for (int i = 0; i < kLCZFeatureCount; i++) {
        const LCZFeatureDef *f = &kLCZFeatures[i];
        NSDictionary *s = saved[[NSString stringWithUTF8String:f->key]];
        gOn[[NSString stringWithUTF8String:f->key]]  = s[@"on"]  ?: @(NO);
        gVal[[NSString stringWithUTF8String:f->key]] = s[@"val"] ?: @(f->defv);
    }
}

static void LCZSavePrefs(void) {
    NSMutableDictionary *d = [NSMutableDictionary new];
    for (NSString *k in gOn) d[k] = @{@"on": gOn[k], @"val": gVal[k] ?: @0};
    [[NSUserDefaults standardUserDefaults] setObject:d forKey:kPrefsKey];
}

BOOL LCZFeatureOn(NSString *key) { LCZLoadPrefs(); return gOn[key].boolValue; }
double LCZFeatureValue(NSString *key) { LCZLoadPrefs(); return gVal[key].doubleValue; }

NSDictionary *LCZBuildInitialState(void) {
    LCZLoadPrefs();
    NSMutableDictionary *out = [NSMutableDictionary new];
    for (NSString *k in gOn) out[k] = @{@"on": gOn[k], @"value": gVal[k] ?: @0};
    return out;
}

#pragma mark - 原始函数指针（hook 后保存）

// 示例 1：移动速度倍率 —— Assets.Core.Models.Characters.CharacterModel::GetSpeed()
// 真实签名需按 metadata 校正；这里按 IL2CPP 实例方法 (this) 处理。
static float (*orig_GetSpeed)(void *self);

static float lcz_GetSpeed(void *self) {
    float base = orig_GetSpeed ? orig_GetSpeed(self) : 0.0f;
    if (!LCZFeatureOn(@"move_speed")) return base;
    double mult = LCZFeatureValue(@"move_speed");
    if (mult <= 0) mult = 1.0;
    return base * (float)mult;
}

// 示例 2：god_mode —— 当前玩家正伤害归零（ProcessHealthAmount）
// 典型签名：void ProcessHealthAmount(this, CharacterModel src, float amount)
static void (*orig_ProcessHealthAmount)(void *self, void *src, float amount);

static void lcz_ProcessHealthAmount(void *self, void *src, float amount) {
    if (LCZFeatureOn(@"god_mode") && amount > 0) amount = 0.0f;
    if (orig_ProcessHealthAmount) orig_ProcessHealthAmount(self, src, amount);
}

// 示例 3：伤害倍率 —— Hit(this, HitInfo*) 形式；参数结构随版本变化，这里只演示"改全局系数"模式
double LCZDamageMultiplier(void) {
    return LCZFeatureOn(@"damage_multiplier") ? LCZFeatureValue(@"damage_multiplier") : 1.0;
}

#pragma mark - 安装 hook

static void LCZInstallHooks(void) {
    LCZLoadPrefs();
    if (!gIl2Cpp) return;

    // 类名/方法名来自逆向得到的 Assets.* 命名空间；找不到就跳过（不同版本可能改名）
    struct { const char *ns, *cls, *meth; int argc; void *detour; void **orig; } table[] = {
        {"Assets.Core.Models.Characters", "CharacterModel", "GetSpeed", 0, (void *)lcz_GetSpeed, (void **)&orig_GetSpeed},
        {"Assets.Core.Models.Characters", "CharacterModel", "ProcessHealthAmount", 2, (void *)lcz_ProcessHealthAmount, (void **)&orig_ProcessHealthAmount},
    };
    for (size_t i = 0; i < sizeof(table)/sizeof(table[0]); i++) {
        if (!LCZHookByName(table[i].ns, table[i].cls, table[i].meth, table[i].argc, table[i].detour, table[i].orig)) {
            NSLog(@"[LCZ] hook 失败: %s::%s", table[i].cls, table[i].meth);
        }
    }
}

#pragma mark - JS 分发

void LCZDispatchJSCommand(NSString *action, NSString *key, id value) {
    LCZLoadPrefs();
    if (!key.length) return;
    if (!gOn[key]) { NSLog(@"[LCZ] 未知功能 key: %@", key); return; }

    BOOL on = [action isEqualToString:@"set"];
    gOn[key] = @(on);
    if (value != nil && value != [NSNull null]) gVal[key] = @([value doubleValue]);

    // 逐功能应用（示例已实现 2 个；其余按 TARGETS.md 的映射往里填即可）
    if ([key isEqualToString:@"move_speed"] || [key isEqualToString:@"god_mode"]) {
        // 由 hook 内部读全局状态，无需额外动作
    } else if ([key isEqualToString:@"damage_multiplier"]) {
        // 由 LCZDamageMultiplier() 供 hook 使用
    } else {
        // TODO: 其余 119 项 —— 目标类/方法见 reimpl/TARGETS.md
        NSLog(@"[LCZ] %@ = %@ (未实现，状态已记录)", key, on ? @(gVal[key].doubleValue) : @"off");
    }
    LCZSavePrefs();
}

// 游戏启动慢：Unity 的 il2cpp 初始化完成（domain 非空）才能查找类。
// 所以轮询等待，最多 90 秒；命中后再装 hook，避免"菜单能开但功能不生效"。
static BOOL LCZWaitForIl2cpp(int timeoutSec) {
    for (int i = 0; i < timeoutSec * 2; i++) {
        if (LCZIl2cppInit() && gIl2Cpp) {
            if (gIl2Cpp->domain_get() != NULL) return YES;
        }
        usleep(500 * 1000);
    }
    return NO;
}

__attribute__((constructor)) static void LCZHooksBoot(void) {
    LCZLoadPrefs();
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        if (!LCZWaitForIl2cpp(90)) {
            NSLog(@"[LCZ] il2cpp 90 秒内未就绪，功能层跳过（菜单仍可用）");
            return;
        }
        NSLog(@"[LCZ] il2cpp domain ready，安装 hooks");
        dispatch_async(dispatch_get_main_queue(), ^{ LCZInstallHooks(); });
    });
}
