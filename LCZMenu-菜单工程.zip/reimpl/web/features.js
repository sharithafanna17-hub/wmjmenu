/* 自动生成：node gen.js —— 数据来自 libLCZMenuHost 的功能描述表 */
window.LCZ_FEATURES = [
 {
  "key": "esp_chests",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "从当前Location.LootObjects/DragBoxObjects读取并投影真实箱子实体。",
  "group": "ESP / 透视",
  "target": {
   "classes": [
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.GameSceneManager",
    "Assets.Core.Sync.Controllers.Battle.Entities.BattleEntitiesController",
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction"
   ],
   "members": [
    "Height",
    "LocationCamera",
    "ContainsKey",
    "CharacterContainer",
    "MeshRenderer",
    "EnemyEntityModel",
    "GameSceneManager",
    "GetPlayerCharacterController",
    "GetController",
    "GetItemId",
    "GetEnumerator",
    "MoveNext"
   ],
   "fromDesc": [
    "LootObjects",
    "DragBoxObjects"
   ],
   "fnRange": "0x5ada4-0x74468"
  }
 },
 {
  "key": "esp_lines",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "真实场景投影连线显示意图，由UI绘制；不修改游戏角色。",
  "group": "ESP / 透视",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "LocationController",
    "GetCorpses",
    "BuilderController",
    "GetBuildingController",
    "Container",
    "Transform",
    "DataToPosition",
    "CharacterContainer",
    "CharacterMove",
    "Transfrom",
    "Add",
    "DisposeRemoveActions"
   ],
   "fromDesc": [],
   "fnRange": "0x8235c-0x9100c"
  }
 },
 {
  "key": "esp_master",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前场景真实实体位置由当前玩家 Camera 投影，只读采样，不以静态配置目录冒充场景对象。",
  "group": "ESP / 透视",
  "target": {
   "classes": [
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.GameSceneManager",
    "Assets.Core.Sync.Controllers.Battle.Entities.BattleEntitiesController",
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction"
   ],
   "members": [
    "Height",
    "LocationCamera",
    "ContainsKey",
    "CharacterContainer",
    "MeshRenderer",
    "EnemyEntityModel",
    "GameSceneManager",
    "GetPlayerCharacterController",
    "GetController",
    "GetItemId",
    "GetEnumerator",
    "MoveNext"
   ],
   "fromDesc": [],
   "fnRange": "0x5ada4-0x74468"
  }
 },
 {
  "key": "esp_names",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "真实场景采样的引用ID/UID文字显示意图，由UI绘制；不虚构本地化名称。",
  "group": "ESP / 透视",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "esp_resources",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "从当前Location.ResourceObjects读取并投影真实资源实体。",
  "group": "ESP / 透视",
  "target": {
   "classes": [
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.GameSceneManager",
    "Assets.Core.Sync.Controllers.Battle.Entities.BattleEntitiesController",
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction"
   ],
   "members": [
    "Height",
    "LocationCamera",
    "ContainsKey",
    "CharacterContainer",
    "MeshRenderer",
    "EnemyEntityModel",
    "GameSceneManager",
    "GetPlayerCharacterController",
    "GetController",
    "GetItemId",
    "GetEnumerator",
    "MoveNext"
   ],
   "fromDesc": [
    "ResourceObjects"
   ],
   "fnRange": "0x5ada4-0x74468"
  }
 },
 {
  "key": "esp_settings",
  "type": 0,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "UI显示设置，包围框/骨骼仅按请求采样真实renderer数据；没有实际数据的个体不画假几何；弹坑金怪/玩家/普通角色沿旧Sponsor实际类型与IsElite判定，独立于荒地主开关；排名独立读取当前QuickRatingModel。",
  "group": "ESP / 透视",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "LocationController",
    "GetCorpses",
    "BuilderController",
    "GetBuildingController",
    "Container",
    "Transform",
    "DataToPosition",
    "CharacterContainer",
    "CharacterMove",
    "Transfrom",
    "Add",
    "DisposeRemoveActions"
   ],
   "fromDesc": [
    "IsElite",
    "QuickRatingModel"
   ],
   "fnRange": "0x8235c-0x9100c"
  }
 },
 {
  "key": "esp_window",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "UnityMain当前场景真实投影；角色按当前真实集合读取，不因屏幕视野或前128个目标截断，屏外及背后角色提供射线方向；弹坑读取当前SyncController真实实体注册表，精确SyncUser分类玩家、EnemyEntityModel.IsEliteField分类金怪，其余普通角色，排除SyncPlayer本人；当前context真实MainCamera投影。非角色保留最多128目�",
  "group": "ESP / 透视",
  "target": {
   "classes": [
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.GameSceneManager",
    "Assets.Core.Sync.Controllers.Battle.Entities.BattleEntitiesController",
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction"
   ],
   "members": [
    "Height",
    "LocationCamera",
    "ContainsKey",
    "CharacterContainer",
    "MeshRenderer",
    "EnemyEntityModel",
    "GameSceneManager",
    "GetPlayerCharacterController",
    "GetController",
    "GetItemId",
    "GetEnumerator",
    "MoveNext"
   ],
   "fromDesc": [
    "UnityMain",
    "SyncController",
    "SyncUser",
    "EnemyEntityModel",
    "IsEliteField",
    "SyncPlayer",
    "MainCamera"
   ],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "backpack_manager",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "clear_buildings",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家基地；原建筑检查与异步结果逐项核验；清理保留有内容家具并继续其余项，明确拒绝逐项记录；已提交结果未知停止不重放",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Models.Builder.Building.PlantFurnitureBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlantGrowthTimeRequirement",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Building.IGradableBuildingDescription",
    "Assets.Core.Models.Builder.Building.IFurnitureBuildingDescription",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.ResourceObjects.ResourceObjectModel",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Models.Builder.Building.IGradableBuilding&",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&"
   ],
   "members": [
    "GetResult",
    "GetRecipeTime",
    "MoveProgress",
    "SetValue",
    "GetValue",
    "UpdateCurrentPlantLevel",
    "MarkChanged",
    "CheckTranslateFurniture",
    "CheckBuildWall",
    "CheckBuildFoundation",
    "BuildGradeWall",
    "BuildGradeFoundation"
   ],
   "fromDesc": [],
   "fnRange": "0x1b420c-0x1d4300"
  }
 },
 {
  "key": "clear_corpses",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前本地地点原ClearDeadCharacters清理规则，核对实际移除的UID；特殊或任务尸体由原规则保留",
  "group": "其它",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "ClearDeadCharacters"
   ],
   "fnRange": null
  }
 },
 {
  "key": "clear_inbox",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "一次确认绑定当前邮箱原邮件集合；128封一批，游标续批只处理原集合，新增邮件保留，异常或场景变化停止",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "clear_stones_grass",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前地点精确对象预览后按 token 分帧清理；尸包物品同步显示并需明确删除确认，变化或失败停止不自动重试",
  "group": "其它",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "drone_blueprints",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "只对当前refs的weapon_drone蓝图BoolFlag.SetActive后读回；独立于枪匠开关和材料；不解锁其他武器蓝图或宣称服务端永久授权",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [
    "BoolFlag",
    "SetActive"
   ],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "drone_dock_station",
  "type": 0,
  "min": 1.795239e-317,
  "max": 1.752903e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "freeze_animals",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前地点真实animal标签角色暂停目标资格、AI、移动及其拥有的动作；本人、狗、机械狗和实际猫宠物独立排除，不以IsPlayerCreated或显示名称判断。",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "LocationController",
    "GetCorpses",
    "BuilderController",
    "GetBuildingController",
    "Container",
    "Transform",
    "DataToPosition",
    "CharacterContainer",
    "CharacterMove",
    "Transfrom",
    "Add",
    "DisposeRemoveActions"
   ],
   "fromDesc": [
    "IsPlayerCreated"
   ],
   "fnRange": "0x8235c-0x9100c"
  }
 },
 {
  "key": "furniture_bar",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.230228e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "furniture_bookshelf",
  "type": 0,
  "min": 1.795239e-317,
  "max": 1.752829e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "furniture_builder_chest",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.228819e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "furniture_electric_parts_box",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.230628e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "furniture_junk_box",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.2160554e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "gasoline_tank",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.230703e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "gasoline_tank_t2",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.231e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "warehouse_manager",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "其它",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "event_contract",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "只对Context.Player为当前玩家的活动ReputationModel临时高级资格；不伪造支付回执或服务端奖励。",
  "group": "地图与传送",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponInventoryStack",
    "Assets.Core.Models.Users.LocationObject",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Builder.Building",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.Users.ObjectComponents",
    "Assets.Core.Models.Users.ObjectComponents.LocationObjectInventoryComponentDescription",
    "Assets.Core.Models.LootObjects",
    "Assets.Core.Models.Transport",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.InventoryModels.InventoryCell.IInventoryCell",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlayerCollectionRequirement",
    "Assets.Core.Manager.Ads"
   ],
   "members": [
    "ContainsModule",
    "HasDuplicatedModuleInSharedSlots",
    "HasIncompatibleModuleInSharedSlots",
    "LocationObjectModel",
    "Contains",
    "ContainsBuilding",
    "LocationModelInventoryExtensions",
    "GetInventoryComponent",
    "LootObjectModel",
    "TransportModel",
    "GetDefault",
    "GetBucket"
   ],
   "fromDesc": [
    "ReputationModel"
   ],
   "fnRange": "0xcf45c-0xd8720"
  }
 },
 {
  "key": "instant_travel",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "仅当前玩家GlobalMapMovement实际移动时返回至少当前取整_distance终点，消除原始几何距离低于Update阈值导致开时不到关后才到；由原Update完成到达事件。",
  "group": "地图与传送",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [
    "GlobalMapMovement"
   ],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "map_refresh",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "所选地点实际冷却资源和原缓存释放链；保留基地、当前运行场景及stash，远端重置仍由原游戏确认；一口粮仅修改实际 auto_tokens 刷新价格表并保留原游戏消费/刷新链，会话变化恢复原表",
  "group": "地图与传送",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "map_teleport",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "调用当前游戏原PlayerChangeLocationReward；场内由原离场保存链切到目标，场外由原EnterLocation进入；地点读回不等于场景加载完成",
  "group": "地图与传送",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "PlayerChangeLocationReward",
    "EnterLocation"
   ],
   "fnRange": null
  }
 },
 {
  "key": "minimap_range",
  "type": 2,
  "min": 0,
  "max": 50,
  "def": 1,
  "desc": "当前场景小地图Radius临时覆盖，读回实际正交相机范围；0跟随原游戏。",
  "group": "地图与传送",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "season_furniture",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧603在当前GameManager实际CheckBuilderRequirement消费者通过StructureView建造资格；材料、数量、位置和服务端限制由原游戏独立处理。",
  "group": "地图与传送",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "CheckUnlocked",
    "GetActualCode",
    "Enter",
    "GetMaximumDurability",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "CheckToComplete",
    "OnFinalizeClick",
    "Manager",
    "Player"
   ],
   "fromDesc": [
    "GameManager",
    "CheckBuilderRequirement",
    "StructureView"
   ],
   "fnRange": "0xd8720-0xe35e0"
  }
 },
 {
  "key": "settlement_temporary",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前定居点房间原 GetRoomInfo 返回等级临时覆盖为实际专业配置最高等级；不写房间/建筑持久字段，关闭恢复原计算",
  "group": "地图与传送",
  "target": {
   "classes": [
    "Assets.Core.Helpers",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "SaveCurrentFile",
    "SaveRootPath",
    "Get",
    "GetCurrentSave",
    "ParseSave",
    "CryptoManager",
    "UnityEngine",
    "Application",
    "SetForcedSave",
    "SaveProgress",
    "CallChanged",
    "Conditions"
   ],
   "fromDesc": [
    "GetRoomInfo"
   ],
   "fnRange": "0x237710-0x240a54"
  }
 },
 {
  "key": "summon_boxes",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前本地地点原CreateDragBox创建箱子，核对真实UID与当前场景；无关对象读取失败不禁用召唤；搬起时删除将旧Take拦截入口与现有RemoveItem组合，仅本人当前地点未搬起目标，关闭恢复原Take",
  "group": "地图与传送",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "CreateDragBox",
    "RemoveItem"
   ],
   "fnRange": null
  }
 },
 {
  "key": "summon_characters",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前本地地点原AddAvatar创建角色，核对真实对象身份与当前场景；无关对象读取失败不禁用召唤",
  "group": "地图与传送",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "AddAvatar"
   ],
   "fnRange": null
  }
 },
 {
  "key": "dog_energy",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "只匹配当前玩家dog_energy真实资源，以实际最大值保持精力，保留原资源事件。",
  "group": "宠物",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "dog_energy",
  "type": 3557283,
  "min": 1.79515e-317,
  "max": 1.795155e-317,
  "def": 1.795158e-317,
  "desc": "categories",
  "group": "宠物",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "dog_grow",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧1301覆盖本人当前自有幼犬CheckGrown；原犬舍成熟操作不耗成长等待，关闭恢复原检查。",
  "group": "宠物",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.PetInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ChildPetInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Arguments.IArguments"
   ],
   "members": [
    "CheckRemoveStack",
    "Clear",
    "GetCats",
    "WeaponInventoryStack",
    "WeaponTimeInventoryStack",
    "DurabilityInventoryStack",
    "VisualizableDurabilityInventoryStack",
    "GetEnumerator",
    "MoveNext",
    "UserModel",
    "ChangeAmount",
    "GetItem"
   ],
   "fromDesc": [
    "CheckGrown"
   ],
   "fnRange": "0xe35e0-0xe8f58"
  }
 },
 {
  "key": "dog_window",
  "type": 0,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "狗功能子窗口与真实功能入口；窗口打开不代表狗狗操作成功。",
  "group": "宠物",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "robodog_energy",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "只匹配当前玩家robodog_energy真实资源，以实际最大值保持电量，保留原资源事件。",
  "group": "宠物",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync",
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "robodog_energy",
  "type": 3633424,
  "min": 1.795155e-317,
  "max": 1.795158e-317,
  "def": 1.795161e-317,
  "desc": "rank",
  "group": "宠物",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync",
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "robodog_reset",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "宠物",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "furniture_decor_storage",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.2303813e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "容器",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "furniture_ore_storage",
  "type": 0,
  "min": 1.795239e-317,
  "max": 2.2309376e-317,
  "def": 5.45352918278e-312,
  "desc": "furniture",
  "group": "容器",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Manager.ModelViews.CameraModelView",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Character",
    "Assets.Core.Game.Battle.Character.CharacterContainer",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Manager.ModelViews",
    "Assets.Core.Models.DomainSpecificLanguage.Reward",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult",
    "Assets.Core.Models.PlayerInventories",
    "Assets.Core.Manager.CryptoManager",
    "Assets.Core.Manager",
    "Assets.Core.Manager.RealSaveProvider",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPriceAction",
    "Assets.Core.Models.DomainSpecificLanguage.Price.SyncPrices.SyncPrice",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.ExternalAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount.CalculatorAmount",
    "Assets.Core.Models.Calculators.ICalculator",
    "Assets.Core.Models.Calculators.TableCalculator",
    "Assets.Core.Helpers",
    "Assets.Core.Models.Builder.IBuilderModel"
   ],
   "members": [
    "CameraSystemController",
    "LocationCamera",
    "CameraTransform",
    "BattleController",
    "CharacterController",
    "CharacterContainer",
    "Transfrom",
    "CameraModelView",
    "UnityEngine",
    "Transform",
    "InverseTransformPoint",
    "Component"
   ],
   "fromDesc": [],
   "fnRange": "0x3296c-0x352a0"
  }
 },
 {
  "key": "fast_workbench",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前本人工艺台原 GetRecipeTime 临时返回 0.1；关闭恢复实际时长",
  "group": "建筑与制作",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "GetRecipeTime"
   ],
   "fnRange": null
  }
 },
 {
  "key": "finalize_build",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧703通过当前玩家建筑集合IsBuilt门槛；当前可见建造交互用原Set补齐材料/事件，再沿原OnFinalizeClick提交，完成以IsCompleted真实读回判断。",
  "group": "建筑与制作",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "CheckUnlocked",
    "GetActualCode",
    "Enter",
    "GetMaximumDurability",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "CheckToComplete",
    "OnFinalizeClick",
    "Manager",
    "Player"
   ],
   "fromDesc": [
    "IsBuilt",
    "OnFinalizeClick",
    "IsCompleted"
   ],
   "fnRange": "0xd8720-0xe35e0"
  }
 },
 {
  "key": "free_craft",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧Sponsor702：当前玩家Research临时通过发现及制作状态；实际InventoryStacksPrice检查与支付同步免材料，不依赖配方白名单或服务器标记。关闭恢复原查询，不写永久发现值。",
  "group": "建筑与制作",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponInventoryStack",
    "Assets.Core.Models.Users.LocationObject",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Builder.Building",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.Users.ObjectComponents",
    "Assets.Core.Models.Users.ObjectComponents.LocationObjectInventoryComponentDescription",
    "Assets.Core.Models.LootObjects",
    "Assets.Core.Models.Transport",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.InventoryModels.InventoryCell.IInventoryCell",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlayerCollectionRequirement",
    "Assets.Core.Manager.Ads",
    "Assets.Core.Models.Builder.Building.PlantFurnitureBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlantGrowthTimeRequirement",
    "Assets.Core.Models.Builder.Building.IGradableBuildingDescription",
    "Assets.Core.Models.Builder.Building.IFurnitureBuildingDescription",
    "Assets.Core.Models.ResourceObjects.ResourceObjectModel",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Models.Builder.Building.IGradableBuilding&",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "InventoryStacksPrice"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "gather_enemies",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "此功能尚无已验证的1.53.2执行适配；窗口与配置目录不能证明游戏操作成功。",
  "group": "建筑与制作",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "grow_plants",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前地点真实树苗沿原DoublePrivate.SetValue和成熟更新；普通/升级/水稻菜圃沿原MoveProgress完成当前一轮，保留材料/产出链并核验实际结果，不修改其他工作台",
  "group": "建筑与制作",
  "target": {
   "classes": [
    "Assets.Core.Models.Builder.Building.PlantFurnitureBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlantGrowthTimeRequirement",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Building.IGradableBuildingDescription",
    "Assets.Core.Models.Builder.Building.IFurnitureBuildingDescription",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.ResourceObjects.ResourceObjectModel",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Models.Builder.Building.IGradableBuilding&",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&"
   ],
   "members": [
    "GetResult",
    "GetRecipeTime",
    "MoveProgress",
    "SetValue",
    "GetValue",
    "UpdateCurrentPlantLevel",
    "MarkChanged",
    "CheckTranslateFurniture",
    "CheckBuildWall",
    "CheckBuildFoundation",
    "BuildGradeWall",
    "BuildGradeFoundation"
   ],
   "fromDesc": [
    "DoublePrivate",
    "SetValue",
    "MoveProgress"
   ],
   "fnRange": "0x1b420c-0x1d4300"
  }
 },
 {
  "key": "repair_infrastructure",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "所选实际桥/叉车/水泵/供电设施的原 Fill→CheckToComplete→StartComplete 链；供电/服务器条件保留，异步完成只按真实模型读回",
  "group": "建筑与制作",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "CheckToComplete",
    "StartComplete"
   ],
   "fnRange": null
  }
 },
 {
  "key": "unlimited_build",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家基地；原建筑检查与异步结果逐项核验；清理保留有内容家具并继续其余项，明确拒绝逐项记录；已提交结果未知停止不重放",
  "group": "建筑与制作",
  "target": {
   "classes": [
    "Assets.Core.Models.Builder.Building.PlantFurnitureBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlantGrowthTimeRequirement",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Building.IGradableBuildingDescription",
    "Assets.Core.Models.Builder.Building.IFurnitureBuildingDescription",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.ResourceObjects.ResourceObjectModel",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Models.Builder.Building.IGradableBuilding&",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&"
   ],
   "members": [
    "GetResult",
    "GetRecipeTime",
    "MoveProgress",
    "SetValue",
    "GetValue",
    "UpdateCurrentPlantLevel",
    "MarkChanged",
    "CheckTranslateFurniture",
    "CheckBuildWall",
    "CheckBuildFoundation",
    "BuildGradeWall",
    "BuildGradeFoundation"
   ],
   "fromDesc": [],
   "fnRange": "0x1b420c-0x1d4300"
  }
 },
 {
  "key": "attack_speed",
  "type": 2,
  "min": 1,
  "max": 10,
  "def": 0.25,
  "desc": "当前玩家 GetAttackSpeedModifier 返回倍率；特殊攻击状态机未覆盖。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount"
   ],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "CameraReset"
   ],
   "fromDesc": [
    "GetAttackSpeedModifier"
   ],
   "fnRange": "0xd510-0x11e1c"
  }
 },
 {
  "key": "bullet_wall",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家攻击动作三类已确认CheckWalls链返回无阻挡，保留原攻击与事件链；不修改全局Physics。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "UnityEngine",
    "WorldToScreenPoint",
    "RenderSettings",
    "SyncCharacterController",
    "SyncController",
    "SyncPlayerCharacterController",
    "SyncUserCharacterController",
    "SkinnedMeshRenderer",
    "Transform",
    "BuilderController",
    "ShowRoof"
   ],
   "fromDesc": [
    "CheckWalls"
   ],
   "fnRange": "0x535f8-0x5ada4"
  }
 },
 {
  "key": "combat_parameters",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "原菜单11项人物/战斗参数分别读取和设置：生命、防御、高度、本人及其他角色体型与转速、普通及重武器范围、扇形角度和爆炸范围；只对当前场景真实对象生效，撤销依据实际覆盖记录，不写共享refs。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.AoeOverheatWeaponAttackLocationActionDescription",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.RadiusWeaponAttackLocationActionDescription",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.ConeWeaponAttackLocationActionDescription",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "GetWeaponDescription",
    "SetAmount",
    "GetAmount",
    "CharacterContainer",
    "Transfrom"
   ],
   "fromDesc": [],
   "fnRange": "0x95b50-0x9fd78"
  }
 },
 {
  "key": "critical_hit",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家WeaponAttackLocationAction共享本体HasCritical判定为真，使原攻击计算处理暴击。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [
    "WeaponAttackLocationAction",
    "HasCritical"
   ],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "damage_multiplier",
  "type": 2,
  "min": 1,
  "max": 999,
  "def": 0.5,
  "desc": "仅 Hit 的 attacker 等于当前玩家时放大正伤害，保留原 Hit 返回与事件链。",
  "group": "战斗",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "CameraReset"
   ],
   "fromDesc": [],
   "fnRange": "0xd510-0x11e1c"
  }
 },
 {
  "key": "freeze_enemies",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前HaveTarget.Check明确返回false，暂停匹配场景角色的AI、移动及其拥有的动作；按真实dog/player/backpack_cat标签和基地猫avatar排除本人及宠物，不以IsPlayerCreated误判归属；沿原ClearTarget清除即时目标，关闭只撤销暂停并由原AI重新寻敌，不回放已释放动作对应的旧目标；失败独立记录。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "LocationController",
    "GetCorpses",
    "BuilderController",
    "GetBuildingController",
    "Container",
    "Transform",
    "DataToPosition",
    "CharacterContainer",
    "CharacterMove",
    "Transfrom",
    "Add",
    "DisposeRemoveActions"
   ],
   "fromDesc": [
    "HaveTarget",
    "IsPlayerCreated",
    "ClearTarget"
   ],
   "fnRange": "0x8235c-0x9100c"
  }
 },
 {
  "key": "god_mode",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "仅当前玩家 ProcessHealthAmount 的正伤害归零；直接写生命资源的其他路径未覆盖。",
  "group": "战斗",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "CameraReset"
   ],
   "fromDesc": [
    "ProcessHealthAmount"
   ],
   "fnRange": "0xd510-0x11e1c"
  }
 },
 {
  "key": "hazard_immunity",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前角色cold/spore资源归零；阻止对应负面state激活和10种当前refs确认的毒气/沼泽/寒冷/孢子effect更新，通过原Remove清除；不影响其他角色或其他效果。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "minigun_ready",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家当前过热武器动作，原AddHeat/AddRotation/过热状态接口预先消热并完成转管，保留实际Shoot与节拍。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [
    "AddHeat",
    "AddRotation"
   ],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "move_speed",
  "type": 2,
  "min": 1,
  "max": 10,
  "def": 0.25,
  "desc": "当前玩家 GetSpeed 返回倍率；不改其他角色或共享描述。",
  "group": "战斗",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "CameraReset"
   ],
   "fromDesc": [
    "GetSpeed"
   ],
   "fnRange": "0xd510-0x11e1c"
  }
 },
 {
  "key": "nailgun_infinite_time",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前背包/装备已有rifle_nailgun的真实本地序列化到期值延长到公元9999年有限上限，逐件读回；不创建物品、不承诺服务器持久化。",
  "group": "战斗",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "never_miss",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家普通及自由武器动作的命中条件通过，保留独立墙体判定和原ProcessHit链。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [
    "ProcessHit"
   ],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "one_hit",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "只在当前玩家攻击非玩家创建的存活Aggressive目标时将伤害至少提升到实际生命值，保留原健康下限与死亡链。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Models.Characters"
   ],
   "members": [
    "Attitude",
    "Aggressive"
   ],
   "fromDesc": [],
   "fnRange": "0x518c0-0x535f8"
  }
 },
 {
  "key": "skill_cooldown",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家技能检查仅临时撤销CooldownTs并保留其余原条件；冷却时长独立返回0。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [
    "CooldownTs"
   ],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "weapon_range",
  "type": 2,
  "min": 0,
  "max": 100,
  "def": 1,
  "desc": "主范围统一当前玩家普通/重武器距离、WeaponView与AOE/Cone真实几何消费者；全图档10000游戏单位，关闭恢复独立高级参数及游戏原值。",
  "group": "战斗",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.AoeOverheatWeaponAttackLocationActionDescription",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.RadiusWeaponAttackLocationActionDescription",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.ConeWeaponAttackLocationActionDescription",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [
    "WeaponView"
   ],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "bunker_code",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "仅玩家已进入A堡Shelter_01_8时读取当前CodeLocationsCollection的bunker实际生成码，交原Enter执行并读回CheckUnlocked；不输出验证码。",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "CheckUnlocked",
    "GetActualCode",
    "Enter",
    "GetMaximumDurability",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "CheckToComplete",
    "OnFinalizeClick",
    "Manager",
    "Player"
   ],
   "fromDesc": [
    "CodeLocationsCollection",
    "CheckUnlocked"
   ],
   "fnRange": "0xd8720-0xe35e0"
  }
 },
 {
  "key": "bypass_sync",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前本人 BuildingCollection.CheckToComplete 通过，原 StartComplete 内 get_ImmediateComplete 返回 true；不伪造服务器回执，关闭恢复原检查",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "REPAIR_SELECTED_INFRASTRUCTURE",
    "Height",
    "CheckToComplete",
    "CharacterController",
    "Fill",
    "StartComplete"
   ],
   "fromDesc": [
    "BuildingCollection",
    "CheckToComplete",
    "StartComplete"
   ],
   "fnRange": "0x1db480-0x1e2248"
  }
 },
 {
  "key": "lockpick_unrestricted",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家NotifyRandomPerkGradeChecker的目标开锁等级需求设0，保留目标及其余检查。",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "NotifyRandomPerkGradeChecker"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "needs_lock",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "只匹配当前角色Stats中的hunger/thirst/cleanliness/defecate；这些是递增负担值，原方法置0并读回。",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "not_ready",
  "type": 9,
  "min": 0,
  "max": 9.88e-321,
  "def": 2.31343e-317,
  "desc": "",
  "group": "杂项 / 风险",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "raider_tasks",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "仅补齐当前玩家已激活的入侵者委托进度，逐项使用原资源方法写入并读回；不自动领取奖励或开启掠夺，不匹配普通剧情任务名称。",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "season_access",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家赛季高级资格同时覆盖本地ResourceRequirement.OnCheck与RewardsBattlePassModel持有的BattlePassModel；资源入口只匹配当前refs实际赛季普通/Plus高级资格根对象，保持赛季等级、奖励数量和其他资源条件；关闭恢复原判定，不写购买标记或伪造服务器响应。",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponInventoryStack",
    "Assets.Core.Models.Users.LocationObject",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Builder.Building",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.Users.ObjectComponents",
    "Assets.Core.Models.Users.ObjectComponents.LocationObjectInventoryComponentDescription",
    "Assets.Core.Models.LootObjects",
    "Assets.Core.Models.Transport",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.InventoryModels.InventoryCell.IInventoryCell",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlayerCollectionRequirement",
    "Assets.Core.Manager.Ads",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "ContainsModule",
    "HasDuplicatedModuleInSharedSlots",
    "HasIncompatibleModuleInSharedSlots",
    "LocationObjectModel",
    "Contains",
    "ContainsBuilding",
    "LocationModelInventoryExtensions",
    "GetInventoryComponent",
    "LootObjectModel",
    "TransportModel",
    "GetDefault",
    "GetBucket"
   ],
   "fromDesc": [
    "ResourceRequirement",
    "OnCheck",
    "RewardsBattlePassModel",
    "BattlePassModel"
   ],
   "fnRange": "0xcf45c-0xd8720"
  }
 },
 {
  "key": "season_max_level",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "task_manager",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "旧MOD的章节/节点语义：当前QuestModel及其Tasks字典；原完成/重启调用链，校验节点归属并读回，部分失败不自动重试",
  "group": "杂项 / 风险",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [
    "QuestModel"
   ],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "gunsmith_blueprints",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家真实蓝图BoolFlag.SetActive后读回；无需其他开关；蓝图学习不等于完成模组，服务器留存未验证",
  "group": "枪械工坊",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [
    "BoolFlag",
    "SetActive"
   ],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "gunsmith_free",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "此功能尚无已验证的1.53.2执行适配；窗口与配置目录不能证明游戏操作成功。",
  "group": "枪械工坊",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "gunsmith_modules",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家全部适用或所选武器模组；枚举真实PlayerCollectionModels成员，写入蓝图标记和Collection.Set材料进度，调用原StartComplete并逐项读回IsCompleted；不要求本地角色或其他开关，服务器留存独立验收",
  "group": "枪械工坊",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [
    "PlayerCollectionModels",
    "StartComplete",
    "IsCompleted"
   ],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "gunsmith_temporary",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧Sponsor607恢复CheckSetModule、ModCollectionController.CheckAvailable和WeaponTableModsController.GetAvailableStatus三个实际入口，并保留原PlayerCollectionRequirement；只当前玩家武器/表台，保留真实槽位兼容、重复检查；关闭即返回原游戏判定，不写永久进度。",
  "group": "枪械工坊",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "CheckSetModule",
    "ModCollectionController",
    "CheckAvailable",
    "WeaponTableModsController",
    "GetAvailableStatus",
    "PlayerCollectionRequirement"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "clear_bodybags",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前地点精确对象预览后按 token 分帧清理；尸包物品同步显示并需明确删除确认，变化或失败停止不自动重试",
  "group": "物品与库存",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "clear_inventory",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "用户确认后，严格当前玩家背包逐格CheckRemoveStack/Clear/读回；装备排除，部分失败逐项报告。",
  "group": "物品与库存",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "CheckRemoveStack"
   ],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "infinite_items",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家背包/装备实物，跳过只负责扣数及清空的ConsumeInventoryItemBehaviour；复合行为中的治疗、奖励仍走原实现。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "ConsumeInventoryItemBehaviour"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "item_catalog",
  "type": 0,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "完整1.53.0物品公开目录、搜索、分页及真实发送入口；配置目录不是玩家库存。",
  "group": "物品与库存",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "magic_split",
  "type": 2,
  "min": 1,
  "max": 999999,
  "def": 1,
  "desc": "当前背包、玩家仓库及真实场景容器中的LimitedInventoryStack及子类先ChangeAmount(N)，再执行一次游戏原Split；箱子、架子、工作台和地上容器与背包共用真实库存归属校验。输入为拆分前增加量，最终两格数量由原游戏决定；保留可写/可取出和空目标格要求，不依赖infinite_items。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "LimitedInventoryStack",
    "ChangeAmount"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "pack_preserve",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧Ayi606保护本人邮箱ShopInboxGachaItem及复用该Take的类型，跳过纯数量扣除；其他邮件、价格与抽奖奖励继续原流程。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.PetInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ChildPetInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Arguments.IArguments"
   ],
   "members": [
    "CheckRemoveStack",
    "Clear",
    "GetCats",
    "WeaponInventoryStack",
    "WeaponTimeInventoryStack",
    "DurabilityInventoryStack",
    "VisualizableDurabilityInventoryStack",
    "GetEnumerator",
    "MoveNext",
    "UserModel",
    "ChangeAmount",
    "GetItem"
   ],
   "fromDesc": [
    "ShopInboxGachaItem"
   ],
   "fnRange": "0xe35e0-0xe8f58"
  }
 },
 {
  "key": "quantity_editor",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.DomainSpecificLanguage.Amount.IAmount",
    "Assets.Core.Models.DomainSpecificLanguage.Amount"
   ],
   "members": [
    "SingleAmount",
    "GetAmount",
    "SetAmount"
   ],
   "fromDesc": [],
   "fnRange": "0x171418-0x17e6ac"
  }
 },
 {
  "key": "quick_chest",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家已合法开始的箱子开锁动作仅临时将等待时间设0，调用原更新/Unlock/Complete链。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "quick_gather",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "沿旧Sponsor405：普通采集撤销前后等待；洗澡、厕所、排泄、梯子、维修、拆卸、终端、沼泽矿与破墙/C4等11类已开始的本人动作加速时间，仍只执行一次原Update，保留工具、资源、奖励与完成链。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription",
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "reclaim_furniture",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前地图家具按旧709强制拆除及原返还链执行；异步移除后仍保留该家具的返还资格，完成或取消后释放对象",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.Builder.Building.PlantFurnitureBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlantGrowthTimeRequirement",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Building.IGradableBuildingDescription",
    "Assets.Core.Models.Builder.Building.IFurnitureBuildingDescription",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.ResourceObjects.ResourceObjectModel",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Models.Builder.Building.IGradableBuilding&",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.Builder"
   ],
   "members": [
    "GetResult",
    "GetRecipeTime",
    "MoveProgress",
    "SetValue",
    "GetValue",
    "UpdateCurrentPlantLevel",
    "MarkChanged",
    "CheckTranslateFurniture",
    "CheckBuildWall",
    "CheckBuildFoundation",
    "BuildGradeWall",
    "BuildGradeFoundation"
   ],
   "fromDesc": [],
   "fnRange": "0x1b420c-0x1d4300"
  }
 },
 {
  "key": "send_full_weapon",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "满配武器数量1至100000；原生分批任务保留配件，每批读回并至少间隔500毫秒；关闭菜单继续，背包按实际容量结束，异常不自动重发",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "send_inventory",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "skins_temporary",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家CharacterSkin临时可用，并沿旧Sponsor607在当前可见载具涂装对话框PaintIsLocked解除本人载具真实涂装资格；不改拥有标记，关闭即恢复原检查。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "CharacterSkin",
    "PaintIsLocked"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "split_equipment",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "独立CheckSplit开关，允许当前背包、玩家仓库及已确认场景容器中的合法单件物品走原游戏Split；保留可写/可取出、空目标格及原克隆/耐久/模组流程，不要求infinite_items，不自行复制或扣数。",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponInventoryStack",
    "Assets.Core.Models.Users.LocationObject",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Builder.Building",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.Users.ObjectComponents",
    "Assets.Core.Models.Users.ObjectComponents.LocationObjectInventoryComponentDescription",
    "Assets.Core.Models.LootObjects",
    "Assets.Core.Models.Transport",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.InventoryModels.InventoryCell.IInventoryCell",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlayerCollectionRequirement",
    "Assets.Core.Manager.Ads"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [
    "CheckSplit"
   ],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "stack_limit",
  "type": 2,
  "min": 0,
  "max": 100000000,
  "def": 1,
  "desc": "当前玩家背包/装备、真实玩家仓库及已确认的场景箱子、架子、工作台、地上物件和载具库存共用堆叠上限；开启且大于0时优先于背包/仓库分容器设置，关闭或设0恢复分容器设置或游戏原上限。按当前集合实例身份与库存反向关联核验，不以家具描述ID冒充唯一实例键，不沿用旧场景对象；保留单件�",
  "group": "物品与库存",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Effect.IEffect",
    "Assets.Core.Game.Dialogs.Craft.Controllers",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.Shop.ShopInboxItem.ShopInboxItemGroupDescription",
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponTimeInventoryStack"
   ],
   "members": [
    "Deactivate",
    "GetAmount",
    "SetAmount",
    "Remove",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "GetResearch",
    "RecipeState",
    "Viewed",
    "Manager"
   ],
   "fromDesc": [],
   "fnRange": "0xb9a60-0xcf45c"
  }
 },
 {
  "key": "cat_window",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "界面",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "game_fps",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "设置并读回 Unity Application.targetFrameRate；不承诺设备实际达到目标。",
  "group": "界面",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ"
   ],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "hub_window",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "任何地图使用玩家库存与原定居点材料奖励，按阿姨版帧节奏排队并转入邮箱；关闭菜单继续发送，显示实际进度和到账结果；每次点击建立新批次，不按地点、旧数量或旧回执阻止发送；成功发送后本地48小时倒计时仅作提醒",
  "group": "界面",
  "target": {
   "classes": [
    "Assets.Core.Models.DomainSpecificLanguage.Reward.IReward",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Models.Description.DebugDictionary`2<System.String,System.Boolean>",
    "Assets.Core.Models.Users.LocationObject.BattleContext",
    "Assets.Core.Models.Users.LocationObject.ILocationObject",
    "Assets.Core.Game.Dialogs.TransportHubTerminal.TransportHubChestDescription",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.InventoryModels.IInventories&",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.LocationActionDescriptionBase",
    "Assets.Core.Models.Builder.Building.DeconstructForRewardFurnitureBuilding",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&",
    "Assets.Core.Models.DomainSpecificLanguage.Reward.RewardResult.IRewardResult"
   ],
   "members": [
    "Height",
    "DialogsManager",
    "DialogsController",
    "GetAmount",
    "ContainsKey",
    "CheckToSelect",
    "CallUse",
    "OnClaimButton",
    "COLLECT_CURRENT_HUB_ITEMS",
    "SCAN_CURRENT_HUB_TARGET",
    "Check",
    "TryGetInventory"
   ],
   "fromDesc": [],
   "fnRange": "0x1e2248-0x1fc014"
  }
 },
 {
  "key": "show_fps",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "读取真实 GameManager.Update 频率；不是 GPU 呈现帧率证明。",
  "group": "界面",
  "target": {
   "classes": [
    "Assets.Core.Manager",
    "Assets.Core.Models.Users.Player",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Game.Battle.CameraSystem.CameraParams",
    "Assets.Core.Manager.GameSceneManager",
    "Assets.Core.Sync"
   ],
   "members": [
    "GameManager",
    "Instance",
    "BattleController",
    "CameraSystemController",
    "CameraHeight",
    "AngleX",
    "AngleY",
    "NormCameraDistance",
    "ResetCameraDistance",
    "GameSceneManager",
    "SyncController",
    "UnityEngine"
   ],
   "fromDesc": [
    "GameManager"
   ],
   "fnRange": "0x93cc-0xd510"
  }
 },
 {
  "key": "vehicle_window",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家自己的载具，型号/驾驶者/场景复核；具体子动作逐项读回，不伪造服务器结果",
  "group": "界面",
  "target": {
   "classes": [
    "Assets.Core.Models.Resources.ExperienceResource",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Arguments.IArguments"
   ],
   "members": [
    "GetAmount",
    "SetAmount",
    "GetAllTransport",
    "MAX_CURRENT_VEHICLE_LEVEL",
    "GetCurrentMaxExperienceAmount",
    "RESET_CURRENT_VEHICLE_POSITION",
    "ResetPosition"
   ],
   "fromDesc": [],
   "fnRange": "0x2540c0-0x25c908"
  }
 },
 {
  "key": "camera_distance",
  "type": 2,
  "min": 1,
  "max": 80,
  "def": 1,
  "desc": "当前本地及弹坑场景相机 GetTargetCameraZPosition/GetCameraDistance 覆盖，包含不经过触摸缩放的相机模式；关闭恢复游戏计算。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "CameraReset"
   ],
   "fromDesc": [
    "GetCameraDistance"
   ],
   "fnRange": "0xd510-0x11e1c"
  }
 },
 {
  "key": "camera_height",
  "type": 2,
  "min": 1,
  "max": 30,
  "def": 1,
  "desc": "当前玩家场景相机每帧临时 CameraHeight，调用后恢复原配置。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [
    "CameraReset"
   ],
   "fromDesc": [
    "CameraHeight"
   ],
   "fnRange": "0x15f18-0x1ec90"
  }
 },
 {
  "key": "camera_sync",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "旧210强制同步：距离覆盖启用时 CalcCameraZPosition 直接返回负距离；关闭后保留距离并恢复原游戏平滑计算。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "CameraReset"
   ],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "camera_x",
  "type": 2,
  "min": 0,
  "max": 360,
  "def": 1,
  "desc": "当前玩家场景相机 AngleY/yaw（度），临时覆盖并恢复。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [
    "CameraReset"
   ],
   "fromDesc": [],
   "fnRange": "0x15f18-0x1ec90"
  }
 },
 {
  "key": "camera_y",
  "type": 2,
  "min": 0,
  "max": 90,
  "def": 1,
  "desc": "当前玩家场景相机 AngleX/pitch（度），临时覆盖并恢复。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [
    "CameraReset"
   ],
   "fromDesc": [],
   "fnRange": "0x15f18-0x1ec90"
  }
 },
 {
  "key": "fog_distance",
  "type": 2,
  "min": -21,
  "max": 30,
  "def": 1,
  "desc": "当前场景 Unity 雾起点相对原值偏移；撤销只恢复本桥仍持有的写值，保留游戏新变化。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "free_run",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "仅当前玩家世界地图奔跑资格、起步价格与当前加速能量价格；不覆盖车辆油费或其他资源。",
  "group": "移动与相机",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle",
    "Assets.Core.Game.Battle.CameraSystem",
    "Assets.Core.Game.Battle.Location.SunLight",
    "Assets.Core.Models.Users",
    "Assets.Core.Models.Location",
    "Assets.Core.Game.Battle.CameraSystem.CameraSystemController",
    "Assets.Core.Game.Battle.Location.SunLight.SunLightSystem",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Manager.GameManager",
    "Assets.Core.Models.Location.LocationViewDescription"
   ],
   "members": [
    "BattleController",
    "CameraSystemController",
    "SunLightSystem",
    "LocationModel",
    "LocationViewDescription",
    "BunkerBattleController",
    "SunLightController",
    "LocationCamera",
    "ViewCamera",
    "SunLight",
    "Color",
    "RenderSettings"
   ],
   "fromDesc": [],
   "fnRange": "0x48b74-0x51890"
  }
 },
 {
  "key": "hide_roofs",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家BuilderController原ShowRoof(false)同时更新屋顶渲染组与家具显隐；撤销恢复游戏最近请求值，不重建或删除建筑。",
  "group": "移动与相机",
  "target": {
   "classes": [
    "Assets.Core.Sync.Controllers.Battle.Entities",
    "Assets.Core.Sync"
   ],
   "members": [
    "UnityEngine",
    "WorldToScreenPoint",
    "RenderSettings",
    "SyncCharacterController",
    "SyncController",
    "SyncPlayerCharacterController",
    "SyncUserCharacterController",
    "SkinnedMeshRenderer",
    "Transform",
    "BuilderController",
    "ShowRoof"
   ],
   "fromDesc": [
    "BuilderController",
    "ShowRoof"
   ],
   "fnRange": "0x535f8-0x5ada4"
  }
 },
 {
  "key": "ignore_floor",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家基地；原建筑检查与异步结果逐项核验；清理保留有内容家具并继续其余项，明确拒绝逐项记录；已提交结果未知停止不重放",
  "group": "移动与相机",
  "target": {
   "classes": [
    "Assets.Core.Models.Builder.Building.PlantFurnitureBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlantGrowthTimeRequirement",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Building.IGradableBuildingDescription",
    "Assets.Core.Models.Builder.Building.IFurnitureBuildingDescription",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.ResourceObjects.ResourceObjectModel",
    "Assets.Core.Models.Users.LocationModel",
    "Assets.Core.Models.Builder.Building.IGradableBuilding&",
    "Assets.Core.Models.Builder.Building.IFurnitureBuilding&"
   ],
   "members": [
    "GetResult",
    "GetRecipeTime",
    "MoveProgress",
    "SetValue",
    "GetValue",
    "UpdateCurrentPlantLevel",
    "MarkChanged",
    "CheckTranslateFurniture",
    "CheckBuildWall",
    "CheckBuildFoundation",
    "BuildGradeWall",
    "BuildGradeFoundation"
   ],
   "fromDesc": [],
   "fnRange": "0x1b420c-0x1d4300"
  }
 },
 {
  "key": "map_brightness",
  "type": 2,
  "min": 1,
  "max": 5,
  "def": 0.25,
  "desc": "当前场景 Unity 环境光强度按实时游戏基线倍率覆盖并读回；撤销恢复实际基线。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "player_fly",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家通过真实Move维持固定Y（未设置高度时3单位），保留原水平碰撞；撤销恢复地面校正与原重力。",
  "group": "移动与相机",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction",
    "Assets.Core.Models.Characters.CharacterModel"
   ],
   "members": [
    "LocationController",
    "GetCorpses",
    "BuilderController",
    "GetBuildingController",
    "Container",
    "Transform",
    "DataToPosition",
    "CharacterContainer",
    "CharacterMove",
    "Transfrom",
    "Add",
    "DisposeRemoveActions"
   ],
   "fromDesc": [],
   "fnRange": "0x8235c-0x9100c"
  }
 },
 {
  "key": "player_height",
  "type": 2,
  "min": 0,
  "max": 40,
  "def": 0.5,
  "desc": "当前玩家固定世界Y；覆盖直接Unity Move中的重力位移，保留原水平碰撞及CollisionFlags，不要求穿墙；关闭恢复原地面定位与重力。",
  "group": "移动与相机",
  "target": {
   "classes": [
    "Assets.Core.Game.Battle.Location.Generation.LocationTerrain.LocationController",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.ILocationAction",
    "Assets.Core.Models.Characters.CharacterModel",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.AoeOverheatWeaponAttackLocationActionDescription",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.RadiusWeaponAttackLocationActionDescription",
    "Assets.Core.Models.DomainSpecificLanguage.LocationActions.Descriptions.ConeWeaponAttackLocationActionDescription"
   ],
   "members": [
    "LocationController",
    "GetCorpses",
    "BuilderController",
    "GetBuildingController",
    "Container",
    "Transform",
    "DataToPosition",
    "CharacterContainer",
    "CharacterMove",
    "Transfrom",
    "Add",
    "DisposeRemoveActions"
   ],
   "fromDesc": [
    "CollisionFlags"
   ],
   "fnRange": "0x8235c-0x9100c"
  }
 },
 {
  "key": "role_view",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家场景相机视角：原视角、第一人称或近肩视角；配置意图与实际相机观察分开读回，关闭恢复原游戏相机。",
  "group": "移动与相机",
  "target": {
   "classes": [],
   "members": [
    "CameraDispose",
    "CameraUpdate",
    "MoveSpeed",
    "AttackSpeed",
    "Hit",
    "Health",
    "Durability",
    "GameUpdate",
    "CameraDistance",
    "CameraTarget",
    "CameraZ",
    "UnityEngine"
   ],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "character_appearance",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "角色与皮肤",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "character_max_level",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "角色与皮肤",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "character_skins",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "角色与皮肤",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "unlock_all_skins",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "角色与皮肤",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "inbox_infinite",
  "type": 2,
  "min": 0,
  "max": 100000,
  "def": 1,
  "desc": "启用后覆盖当前玩家系统新增邮件的数量；0保持原数量，已有邮件不变，手动发送与枢纽转移保留指定数量。",
  "group": "邮件 / 经济",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.PetInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ChildPetInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Arguments.IArguments"
   ],
   "members": [
    "CheckRemoveStack",
    "Clear",
    "GetCats",
    "WeaponInventoryStack",
    "WeaponTimeInventoryStack",
    "DurabilityInventoryStack",
    "VisualizableDurabilityInventoryStack",
    "GetEnumerator",
    "MoveNext",
    "UserModel",
    "ChangeAmount",
    "GetItem"
   ],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "mail_window",
  "type": 0,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "邮件功能导航；真实邮件列表和写操作单独核对。",
  "group": "邮件 / 经济",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": null
  }
 },
 {
  "key": "mailbox_manager",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家模型操作后读回；服务器留存独立验收",
  "group": "邮件 / 经济",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.KittenInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack.ICatInventoryStack",
    "Assets.Core.Models.Characters",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Shop.ShopInboxItem.IShopInboxItem",
    "Assets.Core.Models.InventoryModels.InventoryStack.CatInventoryStackBase",
    "Assets.Core.Models.Arguments.IArguments",
    "Assets.Core.Models.Users.Player"
   ],
   "members": [
    "Item2",
    "Item1",
    "GetAmount",
    "GetMaximumDurability",
    "Dispose",
    "CalculateRank",
    "CanRemoveCat",
    "Height",
    "CharacterController",
    "GetFeedEndTs",
    "GetSkin",
    "CharacterGender"
   ],
   "fromDesc": [],
   "fnRange": "0xe8f58-0x12fdb0"
  }
 },
 {
  "key": "remove_google_ads",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前AdsManager跳过实际SDK展示，沿原ShowRealAd的真实CompletedAwaiter返回Completed；原ShowAd保留Check、ResolveWatchedAds与异步完成回调，不把取消当成功。",
  "group": "邮件 / 经济",
  "target": {
   "classes": [
    "Assets.Core.Models.InventoryModels.InventoryStack.WeaponInventoryStack",
    "Assets.Core.Models.Users.LocationObject",
    "Assets.Core.Models.Users.LocationObject.LocationObjectModel",
    "Assets.Core.Models.InventoryModels.IInventories",
    "Assets.Core.Models.Builder.Building",
    "Assets.Core.Models.Builder.Building.IBuilding",
    "Assets.Core.Models.Users.ObjectComponents",
    "Assets.Core.Models.Users.ObjectComponents.LocationObjectInventoryComponentDescription",
    "Assets.Core.Models.LootObjects",
    "Assets.Core.Models.Transport",
    "Assets.Core.Models.LootObjects.LootObjectModel",
    "Assets.Core.Models.Transport.TransportModel",
    "Assets.Core.Models.InventoryModels.InventoryCell.IInventoryCell",
    "Assets.Core.Models.InventoryModels.InventoryStack.IInventoryStack",
    "Assets.Core.Models.InventoryModels.InventoryStack",
    "Assets.Core.Models.DomainSpecificLanguage.Requirement.PlayerCollectionRequirement",
    "Assets.Core.Manager.Ads",
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "ContainsModule",
    "HasDuplicatedModuleInSharedSlots",
    "HasIncompatibleModuleInSharedSlots",
    "LocationObjectModel",
    "Contains",
    "ContainsBuilding",
    "LocationModelInventoryExtensions",
    "GetInventoryComponent",
    "LootObjectModel",
    "TransportModel",
    "GetDefault",
    "GetBucket"
   ],
   "fromDesc": [
    "AdsManager",
    "ShowRealAd",
    "CompletedAwaiter",
    "ShowAd",
    "ResolveWatchedAds"
   ],
   "fnRange": "0xcf45c-0xd8720"
  }
 },
 {
  "key": "send_inbox",
  "type": 3,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "邮箱多选一次提交至原生任务；关闭菜单继续发送，重新展开读取进度；按真实邮件组容量拆批且至少间隔500毫秒；支持主动停止，异常不自动重发",
  "group": "邮件 / 经济",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [],
   "fnRange": "0x4ea4-0x93cc"
  }
 },
 {
  "key": "skip_craft_coin",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前本人工作台原 SkipPriceAmount / GetSkipPriceAmount 归零，保留原 Skip 完成与奖励链，制作时长不变",
  "group": "邮件 / 经济",
  "target": {
   "classes": [],
   "members": [],
   "fromDesc": [
    "SkipPriceAmount",
    "GetSkipPriceAmount"
   ],
   "fnRange": null
  }
 },
 {
  "key": "survivor_premium",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家EntityContext持有的存活者之路章节/小节临时高级资格；不写购买结果，服务器奖励仍按原服务端检查。",
  "group": "邮件 / 经济",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "CheckUnlocked",
    "GetActualCode",
    "Enter",
    "GetMaximumDurability",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "CheckToComplete",
    "OnFinalizeClick",
    "Manager",
    "Player"
   ],
   "fromDesc": [
    "EntityContext"
   ],
   "fnRange": "0xd8720-0xe35e0"
  }
 },
 {
  "key": "vip_unlock",
  "type": 1,
  "min": 0,
  "max": 0,
  "def": 1,
  "desc": "当前玩家临时VIP资格与等级覆盖，仅处理VIP到期、超级VIP到期和VIP经验条件；关闭恢复原检查，不写到期时间、经验或账户权益。",
  "group": "邮件 / 经济",
  "target": {
   "classes": [
    "Assets.Core.Models.Entity.IEntity",
    "Assets.Core.Models.Builder.Collections.BuildingCollection"
   ],
   "members": [
    "CheckUnlocked",
    "GetActualCode",
    "Enter",
    "GetMaximumDurability",
    "GetValue",
    "Set",
    "CallCollectionItemChanged",
    "CallBuilt",
    "CheckToComplete",
    "OnFinalizeClick",
    "Manager",
    "Player"
   ],
   "fromDesc": [],
   "fnRange": "0xd8720-0xe35e0"
  }
 }
];
