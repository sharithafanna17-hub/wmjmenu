// LCZIL2CPP.h —— UnityFramework 导出的 il2cpp API 绑定（dlsym）
//
// 逆向依据：libLCZMenuHost.dylib 的 __cstring 里有一整组 API 名字符串
// （il2cpp_domain_get / il2cpp_class_from_name / il2cpp_class_get_method_from_name ...），
// 配合 _dlopen / _dlsym 导入，说明 UnityFramework 是以导出符号形式提供这些 API 的。
// 已确认符号在 UnityFramework 导出表：_il2cpp_class_from_name @0xd35xxxx 附近。
#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Il2CppDomain Il2CppDomain;
typedef struct Il2CppAssembly Il2CppAssembly;
typedef struct Il2CppImage Il2CppImage;
typedef struct Il2CppClass Il2CppClass;
typedef struct Il2CppMethod Il2CppMethod;
typedef struct Il2CppObject Il2CppObject;
typedef struct Il2CppString Il2CppString;
typedef struct Il2CppType Il2CppType;
typedef struct Il2CppField Il2CppField;

typedef struct Il2CppAPI {
    Il2CppDomain *(*domain_get)(void);
    const Il2CppAssembly **(*domain_get_assemblies)(Il2CppDomain *domain, size_t *size);
    Il2CppImage *(*assembly_get_image)(const Il2CppAssembly *assembly);
    const char *(*image_get_name)(const Il2CppImage *image);
    Il2CppClass *(*class_from_name)(const Il2CppImage *image, const char *namespaze, const char *name);
    Il2CppClass *(*class_get_parent)(Il2CppClass *klass);
    const char *(*class_get_name)(Il2CppClass *klass);
    const char *(*class_get_namespace)(Il2CppClass *klass);
    bool (*class_is_valuetype)(Il2CppClass *klass);
    Il2CppClass *(*method_get_class)(const Il2CppMethod *method);
    const Il2CppMethod *(*object_get_virtual_method)(Il2CppObject *obj, const Il2CppMethod *method);
    const Il2CppMethod *(*class_get_methods)(Il2CppClass *klass, void **iter);
    const char *(*method_get_name)(const Il2CppMethod *method);
    uint32_t (*method_get_param_count)(const Il2CppMethod *method);
    const Il2CppType *(*method_get_param)(const Il2CppMethod *method, uint32_t index);
    const Il2CppType *(*method_get_return_type)(const Il2CppMethod *method);
    uint32_t (*method_get_flags)(const Il2CppMethod *method, uint32_t *iflags);
    const Il2CppMethod *(*class_get_method_from_name)(Il2CppClass *klass, const char *name, int argsCount);
    Il2CppField *(*class_get_field_from_name)(Il2CppClass *klass, const char *name);
    size_t (*field_get_offset)(Il2CppField *field);
    const Il2CppType *(*field_get_type)(Il2CppField *field);
    void (*field_static_get_value)(Il2CppField *field, void *value);
    void (*field_static_set_value)(Il2CppField *field, void *value);
    Il2CppObject *(*object_new)(Il2CppClass *klass);
    Il2CppString *(*string_new)(const char *str);
    char *(*string_to_utf8)(Il2CppString *str);
    Il2CppObject *(*runtime_invoke)(const Il2CppMethod *method, void *obj, void **params, Il2CppObject **exc);
    void (*free)(void *ptr);
    int32_t (*gchandle_new)(Il2CppObject *obj, bool pinned);
    Il2CppObject *(*gchandle_get_target)(int32_t handle);
    void (*gchandle_free)(int32_t handle);
} Il2CppAPI;

/// 解析 UnityFramework 并填充 API 表；失败返回 NO 并打印缺哪个符号
BOOL LCZIl2cppInit(void);

/// 全局 API 表（LCZIl2cppInit 成功后可用）
extern Il2CppAPI *gIl2Cpp;

/// 按 命名空间 + 类名 在全部 image 里查找类
Il2CppClass *LCZFindClass(const char *namespaze, const char *name);

/// 取方法指针（methodPointer 字段）
void *LCZMethodPointer(const Il2CppMethod *method);

/**
 * 替换 il2cpp 方法的实现：只改 Il2CppMethodInfo->methodPointer，不动代码段。
 * 比内联 hook 干净：不需要 trampoline、不需要 mprotect 代码页、不受 PC 相对指令影响。
 * @param orig 传出原实现指针（可为 NULL）
 * @return 成功与否
 */
BOOL LCZHookMethod(const Il2CppMethod *method, void *detour, void **orig);

/// 便捷组合：按类名/方法名找方法并 hook
BOOL LCZHookByName(const char *ns, const char *cls, const char *meth, int argc, void *detour, void **orig);

/// 读/写实例字段（按字段名 + 对象指针）
BOOL LCZGetFieldValue(Il2CppObject *obj, const char *ns, const char *cls, const char *field, void *outBuf, size_t len);
BOOL LCZSetFieldValue(Il2CppObject *obj, const char *ns, const char *cls, const char *field, const void *inBuf, size_t len);

#ifdef __cplusplus
}
#endif
