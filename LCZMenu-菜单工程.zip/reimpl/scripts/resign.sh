#!/bin/bash
# resign.sh —— 整包重签（ldid 自签 或 指定证书 codesign）
# 用法: ./resign.sh <Payload/xxx.app> [entitlements.plist]
set -euo pipefail
APP="${1:?app 路径}"
ENT="${2:-}"

if [ -n "${LCZ_CERT:-}" ]; then
  echo "使用证书: $LCZ_CERT"
  for f in $(find "$APP" -type f -perm +111 -o -name "*.dylib" -o -name "*.framework/*"); do
    codesign -f -s "$LCZ_CERT" ${ENT:+--entitlements "$ENT"} "$f" 2>/dev/null || true
  done
  codesign -f -s "$LCZ_CERT" ${ENT:+--entitlements "$ENT"} "$APP"
else
  command -v ldid >/dev/null 2>&1 || { echo "!! 需要 ldid 或 LCZ_CERT 证书"; exit 1; }
  for f in $(find "$APP" -type f \( -perm -111 -o -name "*.dylib" \) ); do
    ldid ${ENT:+-S"$ENT"} "$f" 2>/dev/null || true
  done
  ldid ${ENT:+-S"$ENT"} "$APP"
fi

for fw in "$APP"/Frameworks/*.framework; do
  [ -d "$fw" ] || continue
  b=$(basename "$fw" .framework)
  [ -f "$fw/$b" ] || continue
  if [ -n "${LCZ_CERT:-}" ]; then codesign -f -s "$LCZ_CERT" "$fw" 2>/dev/null || true
  else ldid ${ENT:+-S"$ENT"} "$fw" 2>/dev/null || true; fi
done
echo "重签完成"
