#!/bin/bash
set -e
node "$(dirname "$0")/strip_restrict.js" "$1"
