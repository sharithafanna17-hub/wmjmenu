#!/bin/bash
# inject.sh —— 把 libLCZMenu.dylib 注入 LDOE ipa（macOS 环境，需 insert_dylib / ldid）
# 用法: ./inject.sh <原始.ipa> <libLCZMenu.dylib> <输出.ipa>
set -euo pipefail

IPA="${1:?原始 ipa}"
DYLIB="${2:?libLCZMenu.dylib}"
OUT="${3:-LCZMenu-patched.ipa}"

TOOLS="$(dirname "$0")"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "[1/7] 解包"
unzip -q "$IPA" -d "$WORK"
APP="$(ls -d "$WORK"/Payload/*.app | head -1)"
EXE="$APP/$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APP/Info.plist")"
echo "     app: $APP"
echo "     exe: $(basename "$EXE")"

echo "[2/7] 放入 dylib"
mkdir -p "$APP/Frameworks"
cp "$DYLIB" "$APP/Frameworks/libLCZMenu.dylib"
chmod 755 "$APP/Frameworks/libLCZMenu.dylib"

echo "[3/7] 铺网页资源"
mkdir -p "$APP/LCZMenu.bundle/web"
cp "$TOOLS/../web/index.html" "$TOOLS/../web/features.js" "$APP/LCZMenu.bundle/web/" 2>/dev/null || \
  cp "$(dirname "$0")/web/index.html" "$(dirname "$0")/web/features.js" "$APP/LCZMenu.bundle/web/"

echo "[4/7] 注入负载命令"
if command -v insert_dylib >/dev/null 2>&1; then
  insert_dylib --inplace --weak "@executable_path/Frameworks/libLCZMenu.dylib" "$EXE"
elif command -v optool >/dev/null 2>&1; then
  optool install -c load -p "@executable_path/Frameworks/libLCZMenu.dylib" -t "$EXE"
else
  echo "!! 缺少 insert_dylib / optool：brew install insert-dylib（或 optool）" >&2
  exit 1
fi

echo "[5/7] 去掉 __RESTRICT（若有）"
"$(dirname "$0")/strip_restrict.sh" "$EXE" || true

echo "[6/7] 重签"
"$(dirname "$0")/resign.sh" "$APP"

echo "[7/7] 打包"
( cd "$WORK" && zip -qr "$OLDPWD/$OUT" Payload )
echo "完成: $OUT"
