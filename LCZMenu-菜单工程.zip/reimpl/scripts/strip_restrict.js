#!/usr/bin/env node
// 去掉 LC_SEGMENT_64 的 __RESTRICT 段（越狱/注入必需）
const fs=require('fs');
const f=process.argv[2];
const b=fs.readFileSync(f);
const magic=b.readUInt32LE(0);
if(magic!==0xfeedfacf){console.log('not arm64 macho, skip');process.exit(0)}
const ncmds=b.readUInt32LE(16);
let p=32,count=0;
for(let i=0;i<ncmds;i++){
  const cmd=b.readUInt32LE(p),size=b.readUInt32LE(p+4);
  if(cmd===0x19){
    const name=b.toString('latin1',p+8,p+24).replace(/\0/g,'');
    if(name==='__RESTRICT'){
      b.write('__LCLZRK',p+8,'latin1'); count++;
      console.log('renamed __RESTRICT -> __LCLZRK at cmd#',i);
    }
  }
  p+=size;
}
if(count){fs.writeFileSync(f,b);console.log('patched',f)}else{console.log('no __RESTRICT')}
