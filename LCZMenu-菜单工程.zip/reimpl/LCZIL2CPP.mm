// LCZIL2CPP.mm
#import "LCZIL2CPP.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach/mach.h>

Il2CppAPI gApiStorage;
Il2CppAPI *gIl2Cpp = NULL;

static void *LCZFindUnityFrameworkHandle(void) {
    // 优先：已经加载的 UnityFramework
    static const char *paths[] = {
        "@rpath/UnityFramework.framework/UnityFramework",
        "UnityFramework",
        NULL
    };
    for (int i = 0; paths[i]; i++) {
        void *h = dlopen(paths[i], RTLD_LAZY | RTLD_NOLOAD);
        if (h) return h;
    }
    // 回退：遍历已加载 image 找 UnityFramework
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *name = _dyld_get_image_name(i);
        if (name && strstr(name, "UnityFramework")) return dlopen(name, RTLD_LAZY | RTLD_NOLOAD);
    }
    return dlopen("@executable_path/Frameworks/UnityFramework.framework/UnityFramework", RTLD_LAZY);
}

#define LCZ_SYM(table, handle, name) \
    do { \
        *(void **)(&(table)->name) = dlsym(handle, "il2cpp_" #name); \
        if (!(table)->name) { NSLog(@"[LCZ] missing il2cpp_%s", #name); missing++; } \
    } while (0)

BOOL LCZIl2cppInit(void) {
    if (gIl2Cpp) return YES;
    void *h = LCZFindUnityFrameworkHandle();
    if (!h) { NSLog(@"[LCZ] UnityFramework not loadable"); return NO; }

    Il2CppAPI *t = &gApiStorage;
    int missing = 0;
    LCZ_SYM(t, h, domain_get);
    LCZ_SYM(t, h, domain_get_assemblies);
    LCZ_SYM(t, h, assembly_get_image);
    LCZ_SYM(t, h, image_get_name);
    LCZ_SYM(t, h, class_from_name);
    LCZ_SYM(t, h, class_get_parent);
    LCZ_SYM(t, h, class_get_name);
    LCZ_SYM(t, h, class_get_namespace);
    LCZ_SYM(t, h, class_is_valuetype);
    LCZ_SYM(t, h, method_get_class);
    LCZ_SYM(t, h, object_get_virtual_method);
    LCZ_SYM(t, h, class_get_methods);
    LCZ_SYM(t, h, method_get_name);
    LCZ_SYM(t, h, method_get_param_count);
    LCZ_SYM(t, h, method_get_param);
    LCZ_SYM(t, h, method_get_return_type);
    LCZ_SYM(t, h, method_get_flags);
    LCZ_SYM(t, h, class_get_method_from_name);
    LCZ_SYM(t, h, class_get_field_from_name);
    LCZ_SYM(t, h, field_get_offset);
    LCZ_SYM(t, h, field_get_type);
    LCZ_SYM(t, h, field_static_get_value);
    LCZ_SYM(t, h, field_static_set_value);
    LCZ_SYM(t, h, object_new);
    LCZ_SYM(t, h, string_new);
    LCZ_SYM(t, h, string_to_utf8);
    LCZ_SYM(t, h, runtime_invoke);
    LCZ_SYM(t, h, free);
    LCZ_SYM(t, h, gchandle_new);
    LCZ_SYM(t, h, gchandle_get_target);
    LCZ_SYM(t, h, gchandle_free);

    if (missing) { NSLog(@"[LCZ] il2cpp init incomplete (%d missing)", missing); return NO; }
    gIl2Cpp = t;
    NSLog(@"[LCZ] il2cpp ready");
    return YES;
}

Il2CppClass *LCZFindClass(const char *namespaze, const char *name) {
    if (!gIl2Cpp) return NULL;
    size_t count = 0;
    const Il2CppAssembly **asms = gIl2Cpp->domain_get_assemblies(gIl2Cpp->domain_get(), &count);
    for (size_t i = 0; i < count; i++) {
        Il2CppImage *img = gIl2Cpp->assembly_get_image(asms[i]);
        if (!img) continue;
        Il2CppClass *k = gIl2Cpp->class_from_name(img, namespaze, name);
        if (k) return k;
    }
    return NULL;
}

// Il2CppMethodInfo 布局（IL2CPP 24+ / Unity 2021+）：methodPointer 是首字段。
// 运行时自检：读出的指针必须落在可执行区域，否则改用逐项扫描（退化路径）。
static BOOL LCZIsExecutablePointer(void *p) {
    if (!p) return NO;
    Dl_info info;
    if (!dladdr(p, &info)) return NO;
    return info.dli_fbase != NULL;
}

void *LCZMethodPointer(const Il2CppMethod *method) {
    if (!method) return NULL;
    void *p = *(void **)method;
    return LCZIsExecutablePointer(p) ? p : NULL;
}

BOOL LCZHookMethod(const Il2CppMethod *method, void *detour, void **orig) {
    if (!method || !detour) return NO;
    void **slot = (void **)method;                 // methodPointer 在偏移 0
    void *current = *slot;
    if (!LCZIsExecutablePointer(current)) {
        NSLog(@"[LCZ] methodPointer 校验失败，可能需要按版本调整字段偏移：%p", current);
        return NO;
    }
    if (orig) *orig = current;
    vm_protect(mach_task_self(), (vm_address_t)slot, sizeof(void *), false, VM_PROT_READ | VM_PROT_WRITE);
    *slot = detour;
    NSLog(@"[LCZ] hooked %p -> %p", current, detour);
    return YES;
}

BOOL LCZHookByName(const char *ns, const char *cls, const char *meth, int argc, void *detour, void **orig) {
    Il2CppClass *k = LCZFindClass(ns, cls);
    if (!k) { NSLog(@"[LCZ] class %s.%s not found", ns, cls); return NO; }
    const Il2CppMethod *m = gIl2Cpp->class_get_method_from_name(k, meth, argc);
    if (!m) { NSLog(@"[LCZ] method %s not found in %s", meth, cls); return NO; }
    return LCZHookMethod(m, detour, orig);
}

BOOL LCZGetFieldValue(Il2CppObject *obj, const char *ns, const char *cls, const char *field, void *outBuf, size_t len) {
    Il2CppClass *k = LCZFindClass(ns, cls);
    if (!k) return NO;
    Il2CppField *f = gIl2Cpp->class_get_field_from_name(k, field);
    if (!f) return NO;
    size_t off = gIl2Cpp->field_get_offset(f);
    memcpy(outBuf, (uint8_t *)obj + off, len);
    return YES;
}

BOOL LCZSetFieldValue(Il2CppObject *obj, const char *ns, const char *cls, const char *field, const void *inBuf, size_t len) {
    Il2CppClass *k = LCZFindClass(ns, cls);
    if (!k) return NO;
    Il2CppField *f = gIl2Cpp->class_get_field_from_name(k, field);
    if (!f) return NO;
    size_t off = gIl2Cpp->field_get_offset(f);
    memcpy((uint8_t *)obj + off, inBuf, len);
    return YES;
}
