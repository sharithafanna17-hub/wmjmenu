# LCZ Menu 复刻工程（Last Day On Earth 1.53.2 · iOS）

基于对 `地球末日生存 LCZ 苹果 iOS超级mod.ipa` 的静态逆向重建。原版结构：`libLCZMenuHost.dylib` + `LCZProtected.bundle`（WKWebView 网页菜单 + 加密资源 + il2cpp methodPointer hook）。本工程用同样的架构重写，但：

- 菜单前端**自建**（原版 `index.html` 被 Secure Enclave 包裹的密钥加密，静态无解）；
- 功能规格**来自原版明文表**（121 项，见 `TARGETS.md`）；
- 数值输入**不使用系统键盘**，修掉原版"键盘顶大分辨率、界面飞出屏幕"的 bug。

---

## 目录

```
reimpl/
├── LCZIL2CPP.h/.mm          il2cpp API 绑定（dlsym UnityFramework 导出符号）+ methodPointer hook
├── LCZMenuHost.mm           WKWebView 菜单宿主：自定义 scheme、JS 桥、悬浮球、键盘免疫、触摸穿透
├── LCZHooks.mm              功能执行层（表驱动；已实现 2 项示例，其余按 TARGETS.md 填）
├── LCZHooks.generated.h     由 gen.js 生成的 121 项 C 表（勿手改）
├── gen.js                   从 ipa/features.json + ipa/featuremap.json 生成配置
├── web/index.html           菜单 UI（暗色玻璃、分组、滑条、自绘数字键盘）
├── web/features.js          121 项功能配置（自动生成）
├── TARGETS.md               功能 → 目标类/方法 映射（自动生成）
├── Makefile / control       Theos 工程
└── scripts/
    ├── inject.sh            注入 dylib 到 ipa
    ├── resign.sh            重签（ldid 或证书）
    └── strip_restrict.js    去掉 __RESTRICT 段
```

---

## 构建

需要 macOS + Theos（本机 iOS 沙箱内没有 Linux 环境与 clang，构建必须在电脑上做）：

```bash
export THEOS=~/theos
make package                 # 出 deb（越狱机直接装）
# 或只要裸 dylib（注入 ipa 用）
make dylib
```

---

## 注入与签名

```bash
chmod +x scripts/*.sh
./scripts/inject.sh 地球末日生存\ LCZ\ 苹果\ iOS超级mod.ipa libLCZMenu.dylib LCZMenu.ipa
# 用自签证书：
LCZ_CERT="Apple Development: xxx" ./scripts/inject.sh ... 
```

注入脚本会：解包 → 放 `Frameworks/libLCZMenu.dylib` → 铺 `LCZMenu.bundle/web` → `insert_dylib --weak` → 去 `__RESTRICT` → 重签 → 重新打包。

---

## 键盘"顶大分辨率"bug 的修复

原版链路：`input` 聚焦 → 系统键盘 → `keyboardWillShow` → `setInsets` + `geometry` 重算 → `scrollView` 被 WebKit 放大 → 菜单飞出屏幕。

本工程四道闸：

1. **输入层**：数值编辑用页面内自绘九宫格（`#pad`），所有输入元素 `inputmode="none"`，**系统键盘永不弹出**，根本不存在 inset 变化；
2. **视口层**：`maximum-scale=1, minimum-scale=1, user-scalable=no, viewport-fit=cover`；`gesturestart`/`dblclick` 全部 `preventDefault`；输入框字号 ≥16px；
3. **WebView 层**：`scrollView.scrollEnabled = NO`、`bounces = NO`、`contentInsetAdjustmentBehavior = Never`、`minimumZoomScale = maximumZoomScale = 1`、`pinchGestureRecognizer.enabled = NO`、iOS16+ `allowsKeyboardScrolling = NO`；
4. **窗口层**：菜单 `UIWindow` 固定 `UIScreen.bounds` 且 `autoresizingMask = None`；监听键盘四通知，在回调里**强制回写** window/容器/WebView 的 frame、`transform = identity`、`contentInset = zero`、`zoomScale = 1`，并通知页面复位滚动 —— 即"系统改了，我立刻改回来"。

另外：菜单 window **不 makeKey**（键盘输入与游戏输入都留给游戏窗口），容器用 `LCZPassthroughView`（`hitTest` 返回 nil），只有悬浮球与菜单页吃触摸，关闭时完全不挡游戏。

---

## 功能实现进度

| 项 | 状态 |
|---|---|
| 菜单壳 / 桥 / 悬浮球 / 状态持久化 | ✅ 完成 |
| 121 项功能配置（key/类型/范围/默认值/中文说明/分组） | ✅ 完成（自动生成） |
| 功能 → 目标类/方法映射 | ✅ 88/121 有关联类，52/121 有描述点名的方法 |
| `move_speed`、`god_mode` hook | ✅ 示例已写（`LCZHooks.mm`） |
| 其余 119 项 | ⬜ 按 `TARGETS.md` 逐个填 case + 校正方法签名 |

IL2CPP hook 用**替换 `Il2CppMethodInfo->methodPointer`** 的方式，不改代码段：不需 trampoline、不需 mprotect 代码页、不受 PC 相对指令影响。`LCZIL2CPP.mm` 里对指针做了可执行区自检。

---

## 已知限制

- 原版 `index.html` / `command_schema.json` / `feature_schema.json` / `brand.png` 由 **AES-256-GCM + Secure Enclave P-256 包裹**，静态不可解，所以视觉皮肤是本工程自绘的；
- 方法签名（参数个数/类型）需拿 `global-metadata.dat` 逐项校正，`TARGETS.md` 里的 `fromDesc` 列是作者注释点名的方法，`members` 列是同函数内引用的属性名，可作为交叉验证；
- 原版还有 `LCZActivation*`（设备激活）与 `_LCZGameGateAuthorizedForGameplay`（对局门禁），本工程不复刻这两套，直接去掉。
